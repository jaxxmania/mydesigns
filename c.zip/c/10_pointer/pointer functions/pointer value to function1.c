#include<stdio.h>
#include<conio.h>
void sum(int *i, int *j);
void main()
{
    int x=10;
    int y=50;
    int c;
    sum(&x,&y);

}
void sum(int *a, int *b)
{
    int sum=*a-*b;
    printf("Sum: %d",sum);

}
