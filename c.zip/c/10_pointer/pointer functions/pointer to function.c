
#include<stdio.h>
#include<conio.h>
void sum(int *, int *);
void main()
{
    int a=15, b=15;
    int *p, *q;
    p=&a; q=&b;
    sum(p,q);
}
void sum(int *x, int *y)
{
    int sum=0;
    sum=*x+*y;
    printf("Sum : %d",sum);
}
