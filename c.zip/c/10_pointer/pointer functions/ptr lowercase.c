#include<stdio.h>
#include<conio.h>
void info(char *);
void main()
{
    char name[]="krishna";
    info(name);
}
void info(char *name)
{
    printf("\nUppercase : %s",strupr(name));
}
