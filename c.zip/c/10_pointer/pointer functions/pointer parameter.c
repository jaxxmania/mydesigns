#include<stdio.h>
#include<conio.h>
void info(char *, char *);
void main()
{
    char name[50], address[100];
    printf("Enter your name : ");
    scanf("%s",&name);
    printf("Enter your address : ");
    scanf("%s",&address);

    info(name, address);
}
void info(char *name, char *address)
{
    printf("\n\n\n---------------------------------");
        printf("\n----------Personal Inof----------");
        printf("\n---------------------------------");
        printf("\n Name : %s",name);
        printf("\n Address : %s", address);

}
