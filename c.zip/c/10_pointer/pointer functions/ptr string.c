#include<stdio.h>
#include<conio.h>
void info(char *, char *);
void main()
{
    char name[]="krishna";
    char address[]="ktm";
    info(name, address);
}
void info(char *name, char *add)
{
    printf("\nUsername : %s",name);
    printf("\nAddress : %s",add);
}
