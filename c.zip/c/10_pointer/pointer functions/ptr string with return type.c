#include<stdio.h>
#include<conio.h>
char info(char *);
void main()
{
    char re[10], *ptr;
    printf("\nUsername : %s",info(ptr));
}
char info(char *ptr)
{
    char name[]="krishna";
    ptr=name;
    return *ptr;


}
