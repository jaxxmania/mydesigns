#include<stdio.h>
#include<conio.h>
int sum(int *i, int *j);
void main()
{
    int x=10;
    int y=50;
    int c;
    c=sum(&x,&y);
    printf("Sum: %d",c);
}
int sum(int *a, int *b)
{
    int sum=*a+*b;
    return sum;
}
