#include<stdio.h>
#include<conio.h>
void sum(int *i, int *j);
void main()
{
  int n[]={10,20,30};
  int *ip, *ptr[3],i,j;

  for(i=0;i<3; i++)
  {
      ptr[i]=&n[i];
  }

  for(j=0; j<3;j++)
  {
      printf("\nptr[%d] = %d\n",j, *ptr[j]);
  }
}

