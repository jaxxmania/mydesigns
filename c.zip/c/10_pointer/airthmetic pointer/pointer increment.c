#include<stdio.h>
#include<conio.h>
void main()
{
    int a=20;
    int *ip;
    ip=&a;
    printf("pointer address : %d",ip);
    ip--;
    printf("\ndecrement pointer address : %d ",ip);
}
