#include<stdio.h>
#include<conio.h>
void main()
{
int a=5;
int *ptr;

ptr=&a; //2293567
 //after increment:2293580
 //after decrement :

printf("address of a:%u",&a);
//printf("\naddress of pointer : %u",++ptr);
printf("\naddress of pointer : %u",--ptr);
}
