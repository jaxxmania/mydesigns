#include<stdio.h>
#include<conio.h>
void sum(int *,int *);
void main()
{
    int a, b;
    printf("Enter value of a : ");
    scanf("%d",&a);
    printf("Enter value of b : ");
    scanf("%d",&b);

    sum(&a, &b);
}
void sum(int *x, int *y)
{
    int s=0;
    s=*x+*y;
    printf("\n\nTotal sum : %d",s);

}
