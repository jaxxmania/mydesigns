#include<stdio.h>
#include<conio.h>
int sum(int *, int *);
void main()
{
    int a=5, b=10;
    int *x,*y;
    x=&a; y=&b;
    sum(&a,&b);

}
int sum(int *x, int *y)
{
    int add=*x+*y;
    printf("Sum : %d",add);
}
