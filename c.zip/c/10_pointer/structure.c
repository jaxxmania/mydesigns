#include<stdio.h>
#include<conio.h>
#include<string.h>
struct book{
char author[50];
char title[100];
int price;
};
void main()
{
    struct book b1;
    struct book b2;
    /*for book1*/
    strcpy(b1.author,"Ramesh Shaha");
    b1.price=350;



    b2.price=1000;

    printf("\n Book1 Author: %s",b1.author);
    printf("\n Book1 price: %d",b1.price);
    printf("\n Book2 price: %d",b2.price);
}
