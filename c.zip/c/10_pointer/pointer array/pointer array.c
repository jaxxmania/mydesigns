#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    int x[5]={10,20,30,40,50};
    int *pt;
    int i, j;
    pt=x;
    char name[]="aptech";
    int len=strlen(name);
    char *cp;
    cp=name;
    printf("*pt[0]=%d",pt[0]);
    printf("\n\n");
    for(i=0;i<5;i++)
    {
        printf("\npt[%d]=%d",i,pt[i]);
    }
    printf("\n\n\n\n");
    for(j=0;j<len;j++)
    {
        printf("\ncp[%d]=%c",j,cp[j]);
    }
}
