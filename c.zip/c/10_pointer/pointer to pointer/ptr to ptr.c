/* pointer to pointer */
#include<stdio.h>
#include<conio.h>
void main()
{
int a=10;
int *p, **pt, ***ptr;

p=&a;
pt=&p;
ptr=&pt;
printf("\np value : %d\n", *p);
printf("\npt value : %d\n", **pt);
printf("\nptr value : %d\n", ***ptr);
printf("\n\n\n\n\n");


printf("\nOriginal Address : %u\n", &a);
printf("\np Address : %u\n", p);
printf("\npt Address : %u\n", pt);
printf("\nptr Address : %u\n", ptr);
printf("\nptr self Address : %u\n", &ptr);
}
