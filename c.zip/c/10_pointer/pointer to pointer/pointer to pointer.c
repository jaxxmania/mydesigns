#include<stdio.h>
#include<conio.h>
void main()
{
    int a=5, *ptr, **c;
    ptr=&a;
    c=&ptr;




    printf("Address of a : %d",&a);
    //printf("\n Address of ptr : %d",ptr);
    printf("\n Address of c : %d",**c);
}
