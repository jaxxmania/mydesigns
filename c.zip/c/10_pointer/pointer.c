#include<stdio.h>
#include<conio.h>
void main()
{
    int a=20;
    int *ip;
    ip=&a;
    char name[]="aptech";
    char *cp;
    cp=name;


    printf("address of a: %u",&a);
    printf("\naddress of ip: %u",ip);
    printf("\nvalue of a: %d",a);
    printf("\nvalue of pointer: %d",*ip);
    printf("\nName : %s",cp);
}
