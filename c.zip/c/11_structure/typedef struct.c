#include<stdio.h>
#include<conio.h>
typedef struct Books{
char title[30];
float price;
}Book;
void main()
{
    Book b={"CoreJava", 250};
    printf("Book Name : %s",b.title);
    printf("\nBook Price : %0.2f\n\n",b.price);
    printf("\nsize : %d\n\n",sizeof(b));
}
