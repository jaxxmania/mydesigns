#include <stdio.h>
#include <string.h>
void info(struct car c);

struct car{
char brand[50];
char model[50];
int number;
};
int main()
{
    struct car c;
    strcpy(c.brand,"TOYOTA");
    strcpy(c.model,"aa11");
    c.number=1010;
}
void info(struct car c)
{
    printf("Brand :%s",c.brand);
    printf("Model :%s",c.model);
    printf("Number :%d",c.number);
}
