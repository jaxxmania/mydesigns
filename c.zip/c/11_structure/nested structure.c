#include<stdio.h>
struct date{int day, month, year;};
struct person{
char name[20];
int age;
struct date dob;
};
main()
{
    struct person p;
    printf("\nEnter your name :");
    scanf("%s",&p.name);
    printf("\nEnter your age :");
    scanf("%d",&p.age);
    printf("\nEnter your dob(dd mm yyyy :");
    scanf("%d%d%d",&p.dob.day, &p.dob.month, &p.dob.year);
    printf("\n\n----------------------------------");
    printf("\nName : %s",p.name);
    printf("\nAge : %d",p.age);
    printf("\nDate of Birth : %d-%d-%d\n\n",p.dob.day, p.dob.month,p.dob.year);

}






