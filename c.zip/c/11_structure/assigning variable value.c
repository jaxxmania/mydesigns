#include<stdio.h>
#include<conio.h>
struct Book{
    char title[50];
    char author[50];
    int price;
}math={"OPT Math", "Hari", 450};
void main()
{
    struct Book cmath;
    cmath=math;

   printf("Title : %s",cmath.title);
   printf("\nAuthor : %s",cmath.author);
   printf("\nPrice : %d",cmath.price);
}
