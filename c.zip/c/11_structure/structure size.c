#include<stdio.h>
#include<conio.h>
struct Student{
char name[30];
int age;
};
void main()
{
    struct Student s;
    printf("Sizi of S : %u",sizeof(s));
}
