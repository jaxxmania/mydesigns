/*structure */
#include<stdio.h>
#include<conio.h>
struct employee
{
    int eid;
    char name[20];
};
void main()
{
    struct employee e={110, "Ram"};
    struct employee f;

    printf("\nEmployee ID : %d",e.eid);
    printf("\nEmployee Name : %s",e.name);

    printf("\nEnter Employee ID :");
    scanf("%d",&f.eid);
    printf("\nEnter Employee Name :");
    scanf("%s",&f.name);

    printf("\n\n\nEmployee ID : %d",f.eid);
    printf("\nEmployee Name : %s",f.name);
}
