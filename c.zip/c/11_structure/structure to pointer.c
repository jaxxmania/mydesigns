#include<stdio.h>
#include<conio.h>
#include<string.h>
struct book{
char title[50];
int price;
};
void main()
{
    struct book b1;
    struct book *ptr;
    b1.price=350;

    ptr=&b1;
    strcpy(b1.title,"C programming");

    printf("Book Title =%s",(*ptr).title);
    printf("\nBook Price =%d",ptr->price);

}
