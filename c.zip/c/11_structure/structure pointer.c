#include<stdio.h>
#include<conio.h>
struct student{
int sn;
char name[30];
char age;
};
void main()
{
    struct student s={1,"Ramesh", 20};
    struct student *ss;
    ss=&s;

    printf("SN : %d",(*ss).sn);
    printf("\nName : %s",(*ss).name);
    printf("\nAge : %d",(*ss).age);

    printf("\n------------------------\n");
    printf("SN : %d",ss->sn);
    printf("\nName : %s",ss->name);
    printf("\nAge : %d",ss->age);
}
