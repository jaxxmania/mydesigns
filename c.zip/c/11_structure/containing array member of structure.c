#include<stdio.h>
typedef struct{
char name[20];
float marks[2];
}Student;
main()
{
    int n, i, j, x, y;
    Student s[50];

    printf("\nHow many do you want to insert recored? : ");
    scanf("%d",&n);

    for(i=0;i<n; i++)
    {
    printf("\nEnter your name :");
    scanf("%s",&s[i].name);
    for(j=0;j<2;j++)
    {
    printf("\nEnter marks of subject%d :",j+1);
    scanf("%f",&s[i].marks[j]);
    }
    }

    printf("\n-----------------------------------");
    for(x=0;x<n;x++)
    {
    printf("\n\nName : %s",s[x].name);
    for(y=0;y<n;y++)
    {
    printf("\nMarks of subject%d : %0.2f",y+1,s[x].marks[y]);
    }
    }

}
