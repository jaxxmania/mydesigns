#include<stdio.h>
#include<conio.h>
typedef struct{
int sn;
char name[20];
char phone[11];
}Student;
void main()
{
    int i, j, n;
    Student s[10];

    printf("How many records do you want to insert? :");
    scanf("%d",&n);
    for(i=0;i<n; i++)
    {
        printf("\nEnter student sn : ");
        scanf("%d",&s[i].sn);
        printf("\nEnter student name : ");
        scanf("%s",&s[i].name);
        printf("\nEnter student phone no : ");
        scanf("%s",&s[i].phone);
    }
    printf("\n\n\t------------------------------------");
    printf("\n\n\t------------------------------------");
    printf("\n\n\t--------Student Info System---------");
    printf("\n\n\t------------------------------------\n\n");
    printf("\n\tSn \t Name \t Phone No.");
    for(j=0;j<n; j++)
    {
        printf("\n\t%d \t%s \t%s",s[j].sn,s[j].name, s[j].phone);
        printf("\n\n\t-----------------------------------");
    }
}
