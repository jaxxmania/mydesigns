#include<stdio.h>
#include<conio.h>
struct person{
char name[20];
int age;
};
void main()
{
    struct person p[2]={{"ram",20},
                        {"sita",21}};
    printf("Name : %s",p[0].name);
    printf("\nAge : %d\n\n",p[0].age);
    printf("Name : %s",p[1].name);
    printf("\nAge : %d\n\n",p[1].age);

}
