#include<stdio.h>
#include<conio.h>
#include<string.h>
void info();
struct Person{
char name[50];
int age;
};
void main()
{
struct Person p;
info(p);
}
void info(struct Person p)
{
    char name[]="Ram";
    strcpy(p.name,name);
    p.age=24;

    printf("\nName : %s",p.name);
    printf("\nAge : %d",p.age);
}
