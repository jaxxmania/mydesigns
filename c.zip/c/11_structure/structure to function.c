#include<stdio.h>
#include<conio.h>
#include<string.h>
void info();
struct student{
    int roll;
    char name[50];
};
void main()
{
    struct student s1;
    info(s1);
}
void info(struct student s1)
{
   printf("Enter your rollno.:");
   scanf("%d",&s1.roll);
   printf("Enter your Name :");
   scanf("%s",&s1.name);

    printf("\nRollNo. =%d",s1.roll);
    printf("\nName =%s",s1.name);
}
