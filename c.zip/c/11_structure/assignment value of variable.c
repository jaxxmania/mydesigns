#include<stdio.h>
#include<conio.h>
struct person{
char name[20];
int age;
};
void main()
{
    struct person p={"Mohan",20}, q;
    q=p;
    printf("Name : %s",q.name);
    printf("\nAge : %d\n\n",q.age);

}
