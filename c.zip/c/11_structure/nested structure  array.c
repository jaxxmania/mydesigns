#include<stdio.h>
struct date{int day, month, year;};
struct person{
char name[20];
int age;
struct date dob;
};
main()
{
    int n, i, j;
    struct person p[50];

    printf("How many do you want to insert recored? : ");
    scanf("%d",&n);

    for(i=0;i<n; i++)
    {
    printf("\nEnter your name :");
    scanf("%s",&p[i].name);
    printf("\nEnter your age :");
    scanf("%d",&p[i].age);
        printf("\nEnter your dob(dd mm yyyy> :");
        scanf("%d%d%d",&p[i].dob.day, &p[i].dob.month, &p[i].dob.year);

    }
    printf("\n\tName \tAge \tDOB");
    printf("\n-----------------------------------");
    for(j=0;j<n;j++)
    {
    printf("\n\t%s \t%d \t%d-%d-%d",p[j].name,p[j].age,p[j].dob.day, p[j].dob.month, p[j].dob.year);
    }


}
