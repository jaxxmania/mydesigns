#include<stdio.h>
#include<conio.h>
typedef struct{
char brand[50];
char model[50];
int price;
}Mobile;
void main()
{
    Mobile m[2]={ {"SAMSUNG", "Galexy s4", 40000},
                  { "Nokia", "Nokia XL", 17500}};

    printf("\nBrand : %s",m[0].brand);
    printf("\nModel : %s",m[0].model);
    printf("\nPrice : %d\n\n",m[0].price);

    printf("\nBrand : %s",m[1].brand);
    printf("\nModel : %s",m[1].model);
    printf("\nPrice : %d\n\n",m[1].price);

}
