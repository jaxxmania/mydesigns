#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char city[]="KTM";
    int l=strlen(city);
    //int n =city.length();

    printf("\nString length : %d",strlen("Kumaripati"));
    printf("\nString length : %d",l);
}
