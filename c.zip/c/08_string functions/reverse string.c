#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char city[]="Kathmandu";
    int lenght=strlen(city);
    int i;

    printf("Reverse String: ");
    for(i=lenght; i>=0; i--)
    {
        printf("%c",city[i]);

    }


}
