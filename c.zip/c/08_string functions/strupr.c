#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char city[]="ktm";
    printf("\nUppercase : %s",strupr(city));
}
