#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    int a, b, c;
    char s1[]="Ram";
    char s2[]="kumaripati";
    char s3[]="Ram";
    a=strcmp(s1,s3);
    b=strcmp(s1,s2);
    c=strcmpi(s1,s3);

    printf("\nEqual : %d",a);
    printf("\nNot Equal : %d",b);
    printf("\nEqual : %d",c);
}
