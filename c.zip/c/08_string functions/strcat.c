#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char s1[]="Ram";
    char s2[]="Sita";
    printf("\nUppercase : %s",strcat(s1,s2));
}
