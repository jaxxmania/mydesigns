#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char s1[]="Ram";
    char s2[]="kumaripati";

    printf("\nResult : %s",strncat(s1,s2,6));
}
