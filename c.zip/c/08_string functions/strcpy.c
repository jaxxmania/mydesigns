#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char s1[]="Ram";
    char name[10];
    strcpy(name,s1);
    printf("\nResult : %s",name);
}
