#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char city[]="Ktm";
   // strlwr(city);
    printf("\nLowercase : %s",strlwr(city));
}
