#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char city[]="Kathmandu";
    strrev(city);

    printf("String Reverse :%s",city);

}
