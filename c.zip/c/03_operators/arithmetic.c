#include<stdio.h>
#include<conio.h>
void main()
{
    int a=20;
    int b=5;
    int sum=0;

    sum=a+b;
    a++;
    printf("Total subtraction : %d",sum);
    printf("\n)Increment value of a : %d",a);
}
