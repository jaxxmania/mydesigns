#include<stdio.h>

void main()
{
    int x=21, y=5, m;

    m=x%y;

    printf("\n Modulus:%d",m);
}
