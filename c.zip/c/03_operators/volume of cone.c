#include<stdio.h>
#include<conio.h>
 main()
{
    float r=30, h=50, pi=3.14, v;

    v=0.33*3.14*30*30*50;

    printf("volume: %f",v);



}
