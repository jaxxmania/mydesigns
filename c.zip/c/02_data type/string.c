#include<stdio.h>
#include<conio.h>
void main()
{
    char name[]="Aptech Computer Education";
    char address[]="Kumaripati, Lalitpur";

    printf("\n Name: %s",name);
    printf("\n Address: %s",address);
    getch();

}
