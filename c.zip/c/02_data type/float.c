#include<stdio.h>
#include<conio.h>
void main()
{
    float x=10.5;
    float y=5;

    float sum=x+y;

    printf("\n Sum: %f",sum);
    getch();

}
