#include<stdio.h>

void main()
{
    int x, y, sum=0;
    char name[10];

    printf("Enter your name");
    scanf("%s",&name);

    printf("Enter the value of x:");
    scanf("%d",&x);
    printf("Enter value of y:");
    scanf("%d",&y);

    sum=x+y;

    printf("\nName:%s",name);
    printf("\n Sum: %d",sum);
}
