#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    char name[]="APTECH";

    for(i=0; i<6; i++)
   {
       printf("%c",name[i]);
   }

}
