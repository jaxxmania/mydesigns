#include<stdio.h>
#include<conio.h>
void main()
{
    int i, j, a, b;
int x[2][2]={{2, 2},
             {2, 2}};
int y[2][2]={{1, 1},
             {1, 1}};
int sum[2][2];


for(i=0; i<2; i++)
{
    for(j=0; j<2; j++)
    {sum[i][j]=x[i][j]+y[i][j];
    printf("\t%d",x[i][j]);
    }
    printf("\n");

}

for(a=0; a<2; a++)
{
    for(b=0; b<2; b++)
    {printf("\t%d",sum[a][b]);}
    printf("\n");
}
}
