#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    int n[]={10,20,30};
    for(i=0;i<=2;i++)
    {
      printf("\nNumber : %d ",n[i]);
    }

}
