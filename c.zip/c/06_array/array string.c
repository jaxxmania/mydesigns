#include<stdio.h>
#include<conio.h>
#include<string.h>

int main()
{
    char name[]="Kathmandu";

    int n=strlen(name);

    printf("length:%d",n);
    return 0;
}
