#include<stdio.h>
#include<conio.h>
void main()
{
    int i,j;
    int x[2][2]={{10, 20}, {30, 40}};

    printf("x[0][1] = %d",x[0][1]);

    printf("\n\n\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            printf("x[%d][%d] = %d\t",i,j,x[i][j]);
        }
        printf("\n");
    }
}
