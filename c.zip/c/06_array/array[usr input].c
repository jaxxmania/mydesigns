#include<stdio.h>
#include<conio.h>
main()
{
    int num[5];
    int i,j, sum=0;
    for(i=0;i<=4;i++)
    {
        printf("Enter your Number:");
        scanf("%d",&num[i]);
    }
    for(j=0; j<=4;j++)
    {
        sum=sum+num[j];
    }
    printf("Total sum:%d",sum);
}
