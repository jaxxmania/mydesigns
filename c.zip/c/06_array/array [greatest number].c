#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    int n[3]={10, 50, 30};
    int sum=0, great=0;

    for(i=0; i<3; i++)
    {
        if(n[i]>great)
        {
            great=n[i];
        }
        sum=sum+n[i];
    }
    printf("\nGreatest number is : %d",great);
    printf("\nTotal Sum : %d",sum);
}
