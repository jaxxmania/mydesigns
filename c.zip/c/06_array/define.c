#include<stdio.h>
#include<conio.h>
#define p 3.14
#define company "APTECH"
void main()
{
    printf(company);
    printf("\n%f",p);
}
