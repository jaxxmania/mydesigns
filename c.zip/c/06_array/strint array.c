#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    char name[]="ram";
    printf("\nName : %s",name);
    for(i=0; i<4;i++)
    {
        printf("\nCharecter : %c",name[i]);
    }
}
