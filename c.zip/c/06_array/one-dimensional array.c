#include<stdio.h>
#include<conio.h>
int main()
{
    int a[5]={1,2,3,4,5};

    printf("\n%d",a[0]);
    printf("\n%d",a[1]);
    printf("\n%d",a[2]);
    printf("\n%d",a[3]);
    printf("\n%d",a[4]);

    return 0;
}
