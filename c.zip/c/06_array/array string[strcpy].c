#include<stdio.h>
#include<conio.h>
#include<string.h>

int main()
{

    char c[]="Kathmandu";
    char t[10];
    char out=strcpy(t, c);

    printf("Uppercase value : %s",out);
    return 0;
}
