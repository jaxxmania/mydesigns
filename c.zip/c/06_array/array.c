#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    int num[5]={10, 15, 20, 25, 30};

    printf("num : %d",num[3]);

    for(i=0; i<5; i++)
    {
        printf("\n\n\nnum : %d\t",num[i]);
    }

}
