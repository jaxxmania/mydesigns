#include<stdio.h>
#include<conio.h>
#include<string.h>

int main()
{
    char c[]="Kathmandu";
    char =strlwr("Kathmandu");

    printf("Uppercase value : %s",capital);
    return 0;
}
