#include<stdio.h>
#include<conio.h>
void main()
{
    int i, j;
int n[2][3]={{10,20, 50},
             {30,40, 60}};
int num[2][3];


for(i=0; i<2; i++)
{
    for(j=0; j<3; j++)
    {
       printf("\t%d",n[i][j]);
    }
    printf("\n");

}
}
