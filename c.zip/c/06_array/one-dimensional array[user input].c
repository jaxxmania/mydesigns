#include<stdio.h>
#include<conio.h>
int main()
{
    int a[5],i, j;
    for(i=0;i<=4;i++)
    {
    printf("Ener your value:");
    scanf("%d",&a[i]);
    }
    printf("Do you want to show your value?");

    for(j=0;j<=4;j++)
    {
        printf("\n Number:%d",a[j]);
    }
    return 0;
}
