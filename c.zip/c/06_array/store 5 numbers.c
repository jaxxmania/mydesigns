#include<stdio.h>
#include<conio.h>
void main()
{
    int i, j, sum=0;
    int n[5];
    for(i=0; i<5; i++)
    {
        printf("\nEnter number :");
        scanf("%d",&n[i]);
    }
    printf("\nTotal Numbers :\n");
    for(j=0; j<5; j++)
    {
        printf("%d\t",n[j]);
        sum+=n[j];
    }
    printf("\nTotal Sum :%d",sum);
}
