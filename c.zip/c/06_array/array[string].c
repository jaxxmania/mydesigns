#include<stdio.h>
#include<conio.h>

int main()
{
    char n[5]="menu";
    int i;
    for(i=0;i<=3;i++)
    {
        printf("\n n[%d]=%c",i,n[i]);
    }
printf("\n %s",n);
    return 0;
}
