#include<stdio.h>
#include<conio.h>
#define row 2
#define col 2
int main()
{
    int x[row][col]={{1, 2},
                 {1, 2}};

    int y[row][col]={{1, 2},
                 {1, 2}};
    int sum[row][col];

    int i,j;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            sum[i][j]=x[i][j]+y[i][j];
        }

    }
    printf("\nAdd matrix");
    for(i=0;i<2;i++)
    {
        printf("\n");
        for(j=0;j<2;j++)
        {
            printf("%d\t",sum[i][j]);
        }

}

}
