#include<stdio.h>
#include<conio.h>
#define row 2
#define col 2
void main()
{
    int m[row][col];
    int i, j, p, q;
    printf("Enter 2 by 2 Matrix :\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            scanf("\n%d",&m[i][j]);
        }
    }

    printf("Your Matrix is: \n\n");
    for(p=0; p<2; p++)
    {
        for(q=0; q<2; q++)
        {
            printf("%d\t",m[p][q]);
        }
        printf("\n");
    }

}
