#include<stdio.h>
#include<conio.h>
void main()
{
    int n[5]={10,30,40,20,50}
    printf()
}
