/* reading data file */
#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;
f=fopen("myfile.dat","r");
char ch;
while((ch=getc(f))!=EOF)
{printf("%c",ch);}
fclose((f));
}
