#include<stdio.h>
#include<string.h>
void main()
{
    FILE *f;
    int age[5];
    int i, j;
    f=fopen("sum.txt","w");
    printf("Enter 5 Person's Age  :");
    for(i=0; i<5; i++)
    {
        scanf("%d",&age[i]);
        putw(age[i], f);
    }
    printf("\n\n");
    fclose(f);

    f=fopen("sum.txt","r");
    int sum=0,a;
    while((a=getw(f))!=EOF)
    {
      printf("\nAge : %d",a);
      sum+=a;
    }
    printf("\n\nTotal age sum : %d",sum);
    fclose(f);


}




