#include<stdio.h>
#include<conio.h>
void appendData();
void readData();
void deleteData();
void quit();
FILE *f, *fp;
struct product{
int pid;
char name[30];
float price;
}p;
void main()
{
    int choice, sn;
    printf("\n\t******************************************************************");
    printf("\n\t******************************************************************");
    printf("\n\t********** WELCOME TO  YOU IN KR SUPERMARKET INFO SYSTEM *********");
    printf("\n\t******************************************************************");
    printf("\n\t****************************** MENU ******************************");
    printf("\n\t******************************************************************");
            printf("\n\t\t\t\t1. Append Record");
            printf("\n\t\t\t\t2. Read Record");
            printf("\n\t\t\t\t3. Delete Record");
            printf("\n\t\t\t\t4. Exit");
    printf("\n\n\nEnter your choice between 1 to 4 : ");
    scanf("%d",&choice);
    switch(choice)
    {
    case 1:
        appendData();break;
    case 2:
        readData(); break;
    case 3:
        deleteData(); break;
    case 4:
        quit(); break;
    default:
        printf("\n\a\a\tSORRY !!! You entered invalid choice");
        printf("\n\tTry again and enter valid choice");
    }
}
/*--insert record--*/
void appendData()
{
    char next='y';
    f=fopen("product.dat","a");
    while(next=='y' || next=='Y')
    {

        printf("\nEnter product id : ");
        scanf("%d",&p.pid);
         fflush(stdin);
        printf("\nEnter porduct name : ");
        //scanf("%s",p.name);
        gets(p.name);
        printf("\nEnter product price : ");
        scanf("%f",&p.price);
        fflush(stdin);
        fwrite(&p, sizeof(p), 1, f);
        printf("\n\nDo you want add another product (Y/N)? : ");
        next=getche();
    }
    fclose(f);
    getch();
}
/*--Display record--*/
void readData()
{
    f=fopen("product.dat","r");
    printf("\nPID \tProduct Name \t Price");
    while(fread(&p, sizeof(p), 1, f)==1)
    {
        printf("\n%d\t%s\t\t%.2f",p.pid,p.name,p.price);
    }
    fclose(f);
    getch();
}
/*--Delete record--*/
void deleteData()
{
    int id;
    f=fopen("product.dat","r");
    fp=fopen("temp.dat","w");
    printf("\nEnter product id which you want to delete : ");
    scanf("%d",&id);
    while(fread(&p, sizeof(p), 1, f)==1)
    {
        if(id==p.pid)
        {
            printf("\nDelete successfull");
            continue;

        }
        else
        {
            fwrite(&p, sizeof(p), 1, fp);
        }
    }
    fclose(f);fclose(fp);
    remove("product.dat");
    rename("temp.dat","product.dat");
    getch();
}
void quit()
{
 printf("cloing program.. press ENTER Key to confirm");
}



