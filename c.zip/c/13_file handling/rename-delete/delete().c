#include<stdio.h>
#include<conio.h>
void main()
{

    remove("myfile.txt");
    printf("data deleted");
    getch();
}
