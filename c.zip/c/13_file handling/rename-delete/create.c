#include<stdio.h>
#include<conio.h>
void main()
{
    FILE *f;
    f=fopen("Nepal.txt","w");
    printf("file create successful");
    getch();
}
