#include<stdio.h>
void main()
{
    FILE *f;
    char a='z';
    /* ****creating new file**** */
    f=fopen("new1.txt","w");
    putc(a,f);
    fclose(f);

    /* ****openint file**** */
    f=fopen("new1.txt","r");
    char ch;
    while((ch=getc(f))!=EOF)
    {
        printf("%c",ch);
    }


}
