#include<stdio.h>
#include<conio.h>
void main()
{
/*
# fputs(string, file-pointer)          //use to write string text to data file
# Author    : Krishna Yamphu
# Company   : Aptech Computer Education
#             Kumaripati, Lalitpur
*/
FILE *f;
f=fopen("Data1.txt","w");
char text[]="Hello World";
fputs(text,f);
printf("\n\n********* Data write successfully ! *********");
fclose(f);
getche();

}
