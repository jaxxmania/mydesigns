#include<stdio.h>
#include<conio.h>
void main()
{
/*
# fputs(string, file-pointer)          //use to write formated data  to a data file
# Author    : Krishna Yamphu
# Company   : Aptech Computer Education
#             Kumaripati, Lalitpur
*/
FILE *f;
f=fopen(" Data2.txt "," w ");
char text[]= "Hello World";
int num = 2016;
fprintf(f,"%s%d",text,num);
printf("\n\n********* Data write successfully ! *********");
fclose(f);
getche();

}
