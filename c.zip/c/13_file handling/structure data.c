#include<stdio.h>
#include<conio.h>
struct info{
char name[50];
int age;
};
void main()
{
    struct info p;
    FILE *f;

    f=fopen("person.dat","w");
    printf("Enter Your Name :");
    scanf("%s",&p.name);
    printf("Enter your Age :");
    scanf("%d",&p.age);
    fwrite(&p, sizeof(p), 1, f);

    fclose(f);

    f=fopen("person.dat", "r");
    printf("\n\nName \t Age\n");

    while(fread(&p, sizeof(p), 1, f)==1)
    {
        printf("%s\t %d",p.name, p.age);
    }
    fclose(f);
}
