/* reading data file */
#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;
int x[2];
int a, sum=0, i=0, j=0;

f=fopen("number.dat","w");
while(i<2)
{
printf("Enter Numeric vlaue :");
scanf("%d",&x[i]);
putw(x[i],f);
i++;
}fclose(f);

f=fopen("number.dat","r");
printf("\n\n\nNumeric Value is:\n");
while(j<2){
a=getw(f);
printf("%d\t%",a);
sum=sum+a;
j++;
}fclose(f);
printf("\n\nTotal Sum is :%d\n",sum);
}
