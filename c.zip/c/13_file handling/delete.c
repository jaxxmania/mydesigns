#include<stdio.h>
#include<conio.h>
void main()
{
    FILE *f;
    printf("renamed");
    rename("data.txt","nepal_data.txt");
}
