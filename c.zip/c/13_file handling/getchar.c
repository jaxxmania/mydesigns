#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;
f=fopen("file.txt","w");
char name[]="Aptech";
char c;
printf("Enter string : ");
while((c=getchar())!='\n')
{
    putchar(c);
}
}

