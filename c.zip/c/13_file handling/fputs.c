#include<stdio.h>
void main()
{
    FILE *f;
    char name[]="Krishna Yamphu";
    f=fopen("dev.txt", "w");
    fputs(name, f);
    fclose(f);
}
