#include <stdio.h>
#include <string.h>
struct Books
{
   char  title[50];
   int   book_id;
};
int main( )
{
   struct Books Book1;        /* Declare Book1 of type Book */

   strcpy( Book1.title, "C Programming");
   Book1.book_id = 6495407;

   printf( "Book 1 title : %s\n", Book1.title);
   printf( "Book 1 book_id : %d\n", Book1.book_id);

   return 0;
}
