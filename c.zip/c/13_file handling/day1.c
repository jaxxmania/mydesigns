#include<stdio.h>
#include<string.h>
void main()
{
    FILE *f;
    char name[]="Aptech Computer Education";
    int i;
    int len=strlen(name);
    /* ****creating new file**** */
    f=fopen("day1.txt","w");
    for(i=0; i<len; i++)
    {
       putc(name[i],f);
    }

    fclose(f);

    /* ****openint file*****/
    f=fopen("day1.txt","r");
    char ch;

    printf("\n\nCompany Name :");
    while((ch=getc(f))!=EOF)
    {
        printf("%c",ch);
    }
printf("\n\n");

}
