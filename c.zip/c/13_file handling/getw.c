#include<stdio.h>
#include<string.h>
void main()
{
    FILE *f;
    int age=25;

    f=fopen("getw.txt","w");
    putw(age,f);
    fclose(f);

    f=fopen("getw.txt","r");
    int a;
    while((a=getw(f))!=EOF)
    {
      printf("Age : %d",a);
    }
    fclose(f);


}




