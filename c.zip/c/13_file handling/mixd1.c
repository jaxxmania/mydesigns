#include<stdio.h>
#include<conio.h>
#include<ctype.h>
void main()
{
FILE *f;
char name[50];
char add[100];
char phone[10];

f=fopen("info.dat","r");
    printf("\n name, add, tel");
    while(fscanf(f,"%s%s%s", &name, &add, &phone)!=EOF)
    scanf("%S%S%S",name,add,phone);
printf("%s%s%s",name, add, phone);
fclose(f);

}

