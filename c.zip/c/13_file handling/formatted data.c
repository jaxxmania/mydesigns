/* reading data file */
#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;

char name[]="Deepak";
char address[]="Kathmandu";
int age=25;

f=fopen("info.dat","w");

fprintf(f,"\t%s\t%s\t%d", name, address, age);
fclose(f);

f=fopen("info.dat","r");
printf("\tName \t Address \tAge\n");
while(fscanf(f,"%s%s%d", &name, &address, &age)!=EOF)
{
    printf("\t%s\t%s\t %d",name, address, age);
}
fclose(f);
getche();

}
