#include<stdio.h>
void main()
{
    FILE *f;
    char name[]="Krishna Yamphu";
    f=fopen("dev1.txt", "w");
    fprintf(f, "%s %s %s", "My", "Name", "krishna");
    fclose(f);
}
