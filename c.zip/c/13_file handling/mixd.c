#include<stdio.h>
#include<conio.h>
#include<ctype.h>
void main()
{
FILE *f;
char name[50];
char add[100];
char phone[10];

f=fopen("info.dat","a");
char c='y';
while(c=='y')
{
    printf("\nEnter name, add, tel");
    scanf("%S%S%S",name,add,phone);

    printf("\nwant to continue (Y/N)? ");
    c=toupper(getche());
    fflush(stdin);
}
}

