#include<stdio.h>
#include<conio.h>
#include<process.h>
void insertData();
void displayData();
void updateData(int);
void deleteData();
void searchData();
void quit();

int checkRollno(int);
int findLastRollno();

FILE *f, *fp;
struct student{
int sn;
char name[30];
char address[50];
char phone[15];
char course[50];
}s;
void main()
{
    int choice, sn;
    printf("\n\t******************************************************************");
    printf("\n\t******************************************************************");
    printf("\n\t*********** WELCOME TO  YOU IN APTECH COMPUTR EDUCATION **********");
    printf("\n\t******************************************************************");
    printf("\n\t******************* KUMARIPATI, LALITPUR, NEPAL ******************");
    printf("\n\t******************************************************************");
    printf("\n\t****************************** MENU ******************************");
    printf("\n\t******************************************************************");
            printf("\n\t\t\t\t1. Insert Record");
            printf("\n\t\t\t\t2. Display Record");
            printf("\n\t\t\t\t3. Update Record");
            printf("\n\t\t\t\t4. Delete Record");
            printf("\n\t\t\t\t5. Search Record");
            printf("\n\t\t\t\t6. Exit");
    printf("\n\n\nEnter your choice between 1 to 6 : ");
    scanf("%d",&choice);
    switch(choice)
    {
    case 1:
        insertData();break;
    case 2:
        displayData(); break;
    case 3:
        printf("\nEnter student rollno.:");
        scanf("%d",&sn);
        updateData(sn); break;
    case 4:
        deleteData(); break;
    case 5:
        searchData(); break;
    case 6:
       quit(); break;
    default:
        printf("\n\a\a\tSORRY !!! You entered invalid choice");
        printf("\n\tTry again and enter valid choice");
    }

}
void insertData(){
    char next='y';
    int duplicateRoll=0, lastRollno=0;
    while(next=='y' || next=='Y')
    {
        aa:
        printf("\nEnter the student sn: ");
        scanf("%d",&s.sn);
        duplicateRoll=checkRollno(s.sn);
        if(duplicateRoll==1)
        {
            printf("\n\aStudent sn number is aready exists, Try unique sn number");
            lastRollno=findLastRollno();
            printf("\nThe last student sn is : %d\n\n",lastRollno);
            goto aa;
        }
        fflush(stdin);
        printf("\nEnter Student name : ");
        gets(s.name);
        printf("\nEnter student address : ");
        gets(s.address);
        printf("\nEnter student phone : ");
        gets(s.phone);
        printf("\nEnter Course: ");
        gets(s.course);

        f=fopen("student.dat","a");
        if(f==NULL)
        {printf("\n\aFile creation error has occurred !");}
        else{
            fwrite(&s, sizeof(s), 1, f);
            fclose(f);
            printf("\nDo you want to insert record of another student (Y/N)? : ");
            next=getch();
        }
}
}
int checkRollno(int ssn){
    int repeated=0;
    struct student s1;
    f=fopen("student.dat","r");
    if(f==NULL)
    {printf("Student file can not find");}
    else{
        while(fread(&s1, sizeof(s1), 1, f)==1)
        {if(s1.sn==ssn){repeated=1; break;}}
        fclose(f);
    }return repeated;
}
int findLastRollno(){
    int lastrollno;
    f=fopen("student.dat", "r");
    if(f==NULL)
    {printf("\n\aFile open operation failure !!!");}
    else{
        while(fread(&s, sizeof(s), 1, f)==1)
        {lastrollno=s.sn;}
         fclose(f);
        }return lastrollno;
}
/*------------display record-------------*/
void displayData(){
    f=fopen("student.dat","r");
    rewind(f);
    if(f==NULL)
    {printf("\n\afile not found !!!");}
    else{
        printf("\nSN. \tName  \t\tAddress \tPhone \t\tCourse");
        while(fread(&s, sizeof(s), 1, f)==1)
        {printf("\n%d  \t%s \t%s \t%s  \t%s",s.sn,s.name,s.address,s.phone,s.course);}
        }
    fclose(f);
}
/*----------------update recored----------------------------*/
void updateData(int sn)
{
    f=fopen("student.dat","r");
    fp=fopen("student_temp.dat","w");
    if(f==NULL || fp==NULL)
    {printf("\n\aFile Operation Field !");}
    else
    {
        printf("\n\n------------------The following are existing data-------------------");
        printf("\nSN. \tName  \t\tAddress \tPhone \t\tCourse");
        while(fread(&s, sizeof(s), 1, f)==1)
        {
            if(sn==s.sn)
            {
                printf("\n%d  \t%s \t%s \t%s  \t%s",s.sn,s.name,s.address,s.phone,s.course);
            }
        }
        rewind(f);
        printf("\n\nEnter new record:");
        while(fread(&s, sizeof(s), 1, f)==1)
        {
            if(sn==s.sn)
            {
                fflush(stdin);
                printf("\nEnter Student name : ");
                gets(s.name);
                 //fflush(stdin);
                printf("\nEnter student address : ");
                gets(s.address);
                //fflush(stdin);
                printf("\nEnter student phone : ");
                gets(s.phone);
                //fflush(stdin);
                printf("\nEnter Course: ");
                gets(s.course);
                fwrite(&s, sizeof(s), 1, fp);
            }
            else{fwrite(&s, sizeof(s), 1, fp);}
        }
        fclose(f); fclose(fp);
        remove("student.dat");
        rename("student_temp.dat","student.dat");
        printf("\nRecord has been successfully updated");
    }
}
/*--Delete record--*/
void deleteData()
{
    int id;
    f=fopen("student.dat","r");
    fp=fopen("temp.dat","w");
    printf("\nEnter student sn which you want to delete : ");
    scanf("%d",&id);
    while(fread(&s, sizeof(s), 1, f)==1)
    {
        if(id==s.sn)
        {
            printf("\nDelete successfull");
            continue;
        }
        else
        {
            fwrite(&s, sizeof(s), 1, fp);
        }
    }
    fclose(f);fclose(fp);
    remove("student.dat");
    rename("temp.dat","student.dat");
    getch();
}

void searchData()
{
    int ch, ssn, found=0;
    char sname[30];
    printf("\n\t******************************************************************");
    printf("\n\t************************ SEARCH MENU *****************************");
    printf("\n\t******************************************************************");
        printf("\n\t\t1. Search By Name");
        printf("\n\t\t2. Search By SN");
        printf("\n\t\t3. Quit Search");
    fflush(stdin);
    printf("\n\nEnter Choice No.: ");
    scanf("%d",&ch);
    switch(ch)
    {
    case 1:
        fflush(stdin);
        f=fopen("student.dat","r");
        printf("\nEnter Student's Name : ");
        gets(sname);
        if(f==NULL)
        {
            printf("Operation field");
        }
        else{
             printf("\nSN. \tName  \t\tAddress \tPhone \t\tCourse");
            while(fread(&s, sizeof(s), 1, f)==1)
            {
                if(strcmpi(s.name,sname)==0)
                {printf("\n%d  \t%s \t%s \t%s  \t%s",s.sn,s.name,s.address,s.phone,s.course); found=1;}
            }
            if(found==0)
            {printf("\nfile cannot found!!!");}
            fclose(f);
            }
            break;
    case 2:
        fflush(stdin);
        f=fopen("student.dat","r");
        printf("\nEnter Student's SN : ");
        scanf("%d",&ssn);
        if(f==NULL)
        {
            printf("Operation field");
        }
        else{
             printf("\nSN. \tName  \t\tAddress \tPhone \t\tCourse");
            while(fread(&s, sizeof(s), 1, f)==1)
            {
                if(ssn==s.sn)
                {printf("\n%d  \t%s \t%s \t%s  \t%s",s.sn,s.name,s.address,s.phone,s.course); found=1;}
            }
            if(found==0)
            {printf("\nfile cannot found!!!");}
            fclose(f);
            }
            break;
    case 3:
        quit();break;
    default:
        printf("\nInvalid choice"); break;
    }
}
void quit()
{printf("Terminating Program.... press any key.");}







