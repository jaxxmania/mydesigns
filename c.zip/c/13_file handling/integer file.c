/* reading data file */
#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;
int x=50, y;

f=fopen("number.dat","w");
putw(x,f);
fclose(f);

f=fopen("number.dat","r");
y=getw(f);

printf("Numeric Value is:\n");
printf("%d",y);
fclose(f);

}
