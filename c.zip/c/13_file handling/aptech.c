/* reading data file */
#include<stdio.h>
#include<conio.h>
void insertData();
void displayData();
void deleteData();

FILE *f, *fp;
struct student{
int sid;
char name[30];
char address[50];
char phone[10];
char course[15];
}s;
void main()
{
    int choice;
    printf("\n\t*************************************************************");
    printf("\n\t*************************************************************");
    printf("\n\t************ WELCOME TO STUDENT INFO SYSTEM *****************");
    printf("\n\t*************************************************************");
    printf("\n\t********************** MENU *********************************");
    printf("\n\t*************************************************************");
        printf("\n\t\t1. Inserd record");
        printf("\n\t\t2. Display record");
        printf("\n\t\t3. Delete record");
        printf("\n\t\t4. Quit");

    printf("\nEnter your choice from 1 to 4: ");
    scanf("%d",&choice);
    switch(choice)
    {
    case 1:
        insertData(); break;
    case 2:
        displayData(); break;
    case 3:
        deleteData(); break;
    default:
        printf("\n\aYou entered invalid choice no."); break;

    }
}
void insertData()
{
    char next='y';
    f=fopen("student.dat","a");
    while(next=='y'|| next=='Y')
    {
        printf("\nEnter Student ID : ");
        scanf("%d",&s.sid);
        fflush(stdin);
        printf("\nEnter Student Name : ");
        scanf("%s",&s.name);
        printf("\nEnter Student Address : ");
        scanf("%s",&s.address);
        printf("\nEnter Student Phone No. : ");
        scanf("%s",&s.phone);
        printf("\nEnter Student Course : ");
        scanf("%s", &s.course);

        fwrite(&s, sizeof(s), 1, f);

        printf("\nDo you want to add another record (Y/N)? : ");
        next=getche();
    }
    fclose(f);
}
/*---display data-----*/
void displayData()
{
    f=fopen("student.dat","r");
    printf("\nID \tName \t Address \tPhone \t\tCourse");
    while(fread(&s, sizeof(s), 1, f)==1)
    {
        printf("\n%d \t%s \t%s \t%s \t\t%s",s.sid,s.name,s.address,s.phone,s.course);
    }
    fclose(f);
}
/*--------delete data-------*/
void deleteData()
{
    int id;
    printf("Enter Student ID :");
    scanf("%d",&id);
    f=fopen("student.dat","r");
    fp=fopen("temp_student.dat","w");
    while(fread(&s, sizeof(s), 1, f)==1)
    {
        if(id==s.sid)
        {
            printf("Data Delete Successfully.");
            continue;
        }
        else
            {
                fwrite(&s, sizeof(s), 1, fp);
            }
    }
    fclose(f);
    fclose(fp);
    remove("student.dat");
    rename("temp_student.dat","student.dat");
}








