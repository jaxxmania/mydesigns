#include<stdio.h>
#include<string.h>
void main()
{
    FILE *f;
    char name[]="Aptech Computer";
    char address[]="Kumaripati";

    f=fopen("fprintf.dat","w");
    fprintf(f,"%s\n%s",name, address);
    fclose(f);
}
