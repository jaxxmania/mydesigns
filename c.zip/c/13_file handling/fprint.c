#include<stdio.h>
#include<string.h>
void main()
{
    FILE *f;
    char name[50], address[100];
    int age;

    printf("Enter Name : ");
    scanf("%s",&name);
    printf("Enter Address : ");
    scanf("%s",&address);
    printf("Enter Age : ");
    scanf("%d",&age);

    f=fopen("fprint.txt","w");
    fprintf(f,"%s%s%d",name, address,age);
    fclose(f);

    f=fopen("fprint.txt","r");
    while(fscanf(f,"%s%s%d",name,address,age)!=EOF)
{
printf("%s%s%d",name, address, age);
}
}




