#include<stdio.h>
#include<string.h>
void main()
{
    FILE *f;
    char txt[]="Aptech Computer";

    /* ****creating new file**** */
    printf("write some content :\n");
    f=fopen("day3.dat","w");
   fputs(txt,f);

    fclose(f);


printf("\n\n");

}
