#include<stdio.h>
#include<conio.h>
void main()
{

FILE *f;
char s[]="I love my Nepal.";
char c;
int i=0;
f=fopen("data1.dat","w");
while(s[i]!='\0')
{
    putc(s[i], f);
    i++;
}
fclose(f);

printf("\n\n");
f=fopen("data1.dat","a+");
while((c=getc(f))!=EOF)
{
    printf("%c",c);
}
fclose(f);
printf("\n\n");
getch();
}

