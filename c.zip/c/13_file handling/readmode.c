/* reading data file */
#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;
char s, c;
f=fopen("data.dat","r+");
printf("Existing Data:\n");
while((s=getc(f))!=EOF)
{printf("%c",s);
}fclose(f);


f=fopen("data.dat","r+");
printf("\nEnter New Data :\n");
while((c=getchar())!='\n')
{putc(c,f);
}fclose(f);

}
