#include<stdio.h>
#include<conio.h>
#include<string.h>
void menu();
void inserRcored();
void displayRecord();
void updateRecord();
void quit();
typedef struct{
char title[20];
char author[20];
int price;
}Book;
FILE *f, *fp;
Book b;
void main()
{
    int choice;
    menu();
    printf("\n\nEnter choice number (1 to 5) : ");
    scanf("%d",&choice);
    switch(choice)
    {
    case 1:
        inserRcored(); break;
    case 2:
        displayRecord(); break;
    case 3:
        updateRecord(); break;
    case 5:
        quit(); break;
    default:
        printf("\n\a\a\aInvalid Choice !!!"); break;

    }
}
/*print menu*/
void menu()
{
    printf("\n\t---------------------------------------------------------------");
    printf("\n\t---------------------------------------------------------------");
    printf("\n\t--------------- WELCOME TO BOOK INFO SYSTEM -------------------");
    printf("\n\t---------------------------------------------------------------");
    printf("\n\t--------------------------- MENU  -----------------------------");
    printf("\n\t---------------------------------------------------------------");
        printf("\n\t\t1. Insert records");
        printf("\n\t\t2. Display records");
        printf("\n\t\t3. Update records");
        printf("\n\t\t4. Delete records");
        printf("\n\t\t5. Quit");
}

/*insert records */
void inserRcored()
{
    char ch='y';
    f=fopen("book.txt","a");
    while(ch=='y' || ch=='Y')
    {
        printf("\nEnter Book Title : ");
        scanf("%s",&b.title);
        fflush(stdin);
        printf("\nEnter Book Author : ");
        scanf("%s",&b.author);
        printf("\nEnter Book Price : ");
        scanf("%d",&b.price);
        fwrite(&b,sizeof(b), 1, f);

        /*promptfor add another records*/
        printf("\n\nDo you want to add another records (Y/N) : ");
        ch=getche();
    }
    fclose(f);
}

/*display records*/
void displayRecord()
{
    f=fopen("book.txt","r");
    printf("\nTitle \tAuthor \tPrice");
    printf("\n-------------------------");
    while(fread(&b, sizeof(b),1,f)==1)
    {
        printf("\n%s \t%s \t%d",b.title,b.author,b.price);
        printf("\n-------------------------");
    }
    fclose(f);
}


/*update record*/
void updateRecord()
{
    char title[20];
    f=fopen("book.txt","r");
    fp=fopen("temp_book.txt","w");

    printf("Enter book title : ");
    scanf("%s",&title);
    printf("\nFollowing are existing data : ");
    printf("\nTitle \tAuthor \tPrice");
    printf("\n-------------------------");
    while(fread(&b, sizeof(b),1, f)==1)
    {
        if(strcmpi(title,b.title)==0)
        {
          printf("\n%s \t%s \t%d\n",b.title,b.author,b.price);
        }
        //else{printf("\n\a\aNo data found !!!"); break;}

    }
    rewind(f);
    fflush(stdin);
    while(fread(&b, sizeof(b),1, f)==1)
    {
        if(strcmpi(title,b.title)==0)
        {
            fflush(stdin);
            printf("\nEnter Book Title : ");
            scanf("%s",&b.title);
            fflush(stdin);
            printf("\nEnter Book Author : ");
            scanf("%s",&b.author);
            printf("\nEnter Book Price : ");
            scanf("%d",&b.price);
            fwrite(&b,sizeof(b),1,fp);
        }
        else{
            fwrite(&b,sizeof(b),1,fp);
        }
    }
    fclose(f);
    fclose(fp);
    remove("book.txt");
    rename("temp_book.txt","book.txt");
    printf("\nUpdate Successfully !");
}

/*close program*/
void quit()
{
    printf("\nEnter any KEY to EXIT :");
}






