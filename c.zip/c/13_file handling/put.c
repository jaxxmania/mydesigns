/* reading data file */
#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;

printf("\n Ennter Your Text Value :");

f=fopen("myfile.dat","w");
char c, ch;
while((c=getchar())!='\n')
{
    putc(c,f);
}

fclose(f);

printf("\n\nYour Text value:");
f=fopen("myfile.dat","r");
while((ch=getc(f))!=EOF)
{
    printf("%c",ch);}
fclose(f);
printf("\n\n");
}
