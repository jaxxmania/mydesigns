#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;
int x, y, sum=0;
f=fopen("math.dat","w");
printf("Enter the value of x:");
scanf("%d",&x);

printf("Enter the value of y:");
scanf("%d",&y);

putw(y,f);

sum=x+y;

printf("\n Value of x is:\n%d",sum);
fclose(f);
getch();
}

