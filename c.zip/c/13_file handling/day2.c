#include<stdio.h>
#include<string.h>
void main()
{
    FILE *f;
    char txt;
    int i=0;
    //int len=strlen(name);
    /* ****creating new file**** */
    printf("write some content :\n");
    f=fopen("day2.txt","w");
    while((txt=getchar())!='\n')
    {
        putc(txt,f);
    }

    fclose(f);

    /* ****openint file    ******/
    f=fopen("day2.txt","r");
    char ch;

    printf("\n\nParagraph content :\n\n");
    while((ch=getc(f))!=EOF)
    {
        printf("%c",ch);
    }
printf("\n\n");

}
