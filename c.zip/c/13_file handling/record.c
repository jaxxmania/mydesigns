/* reading data file */
#include<stdio.h>
#include<conio.h>
void main()
{
FILE *f;

char name[20];
char address[30];
int age;
int i, n;


printf("How many record do you want to add? :");
scanf("%d",&n);

printf("\nEnter Name Address Age:\n");
f=fopen("record.dat","w");
for(i=0;i<n;i++)
{
    scanf("%s%s%d",&name, &address, &age);
    fprintf(f,"\t%s\t%s\t%d", name, address, age);
}
fclose(f);


f=fopen("record.dat","r");
printf("Total %d Records:\n",n);
printf("\tName \t Address \tAge\n");
while(fscanf(f,"%s%s%d", &name, &address, &age)!=EOF)
{
    printf("\t%s\t%s\t %d\n",name, address, age);
}
fclose(f);
getche();

}
