

document.write(' \
<style type="text/css" media="screen">\
	 .dsq-widget ul.dsq-widget-list {\
	 padding: 0;\
	 margin: 0;\
	 text-align: left;\
	 }\
	 img.dsq-widget-avatar {\
	 width: 32px;\
	 height: 32px;\
	 border: 0px;\
	 margin: 0px;\
	 padding: 0px 3px 3px 0px;\
	 float: left;\
	 }\
	 a.dsq-widget-user {\
	 font-weight: bold;\
	 }\
	 a.dsq-widget-thread {\
	 font-weight: bold;\
	 }\
	 p.dsq-widget-meta {\
	 clear: both;\
	 font-size: 80%;\
	 padding: 0;\
	 margin: 0;\
	 }\
	 li.dsq-widget-item {\
	 margin: 15px 0;\
	 list-style-type: none;\
	 clear: both;\
	 }\
	 span.dsq-widget-clout {\
	 padding: 0 2px;\
	 background-color: #ff7300;\
	 color: #fff;\
	 }\
	 table.dsq-widget-horiz td {\
	 padding-right: 15px;\
	 }\
	 .dsq-widget-comment p {\
	 display: inline;\
	 }\
	 </style>\
	 <ul class="dsq-widget-list">\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/pokarjm/">Jayesh</a>\
	 <span class="dsq-widget-comment"><p>nicely explained with implementation:...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/print-nodes-top-view-binary-tree/">Print Nodes in Top View of Binary Tree</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/print-nodes-top-view-binary-tree/#comment-2297908238">0 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/josephtribbiani/">Joey Tribbiani</a>\
	 <span class="dsq-widget-comment"><p>you can put 248 apples in any random way in the...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/accolite-interview-experience-set-9-on-campus/">Accolite Interview Experience | Set 9 (On-Campus)</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/accolite-interview-experience-set-9-on-campus/#comment-2297895857">17 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/geeksforgeeks/">GeeksforGeeks</a>\
	 <span class="dsq-widget-comment"><p>Thanks, we have received the mail.</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/data-structures/">Data Structures</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/data-structures/#comment-2297894415">19 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/josephtribbiani/">Joey Tribbiani</a>\
	 <span class="dsq-widget-comment"><p>CTC ?</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/sap-labs-interview-experience-set-12-on-campus/">SAP Labs Interview Experience | Set 12 (On-Campus)</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/sap-labs-interview-experience-set-12-on-campus/#comment-2297890903">24 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/khatarnak_khatri/">Khatri</a>\
	 <span class="dsq-widget-comment"><p>Interesting Question: Can we use Dijksra’s...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/greedy-algorithms-set-6-dijkstras-shortest-path-algorithm/">Greedy Algorithms | Set 7 (Dijkstra&#8217;s shortest path algorithm)</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/greedy-algorithms-set-6-dijkstras-shortest-path-algorithm/#comment-2297876677">44 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/disqus_TRgijcl5mK/">Shubham Sharma</a>\
	 <span class="dsq-widget-comment"><p>in line while (currX &amp;&amp; currX-&gt;data != x) i...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/swap-nodes-in-a-linked-list-without-swapping-data/">Swap nodes in a linked list without swapping data</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/swap-nodes-in-a-linked-list-without-swapping-data/#comment-2297871354">52 minutes ago</a></p>\
	 </li>\
	 </ul>\
');
