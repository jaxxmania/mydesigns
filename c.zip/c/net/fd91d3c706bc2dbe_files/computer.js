function ggad336x280()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- whitebg_blackfont_bluelink -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:336px;height:280px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"9538995218\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function computer_2()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- whitebg_blackfont_bluelink -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:336px;height:280px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"9538995218\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function computer_728x90()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- ad_728x90_m -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:728px;height:90px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"2505222666\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function computer_search()
{

	document.body.oncopy=function () 
	{ 
	setTimeout( function () { 
		var text=clipboardData.getData("text");
		if (text) { 
		text=text + "\r\n"+location.href;
		clipboardData.setData("text", text);
		}
	}, 100 ) 
	}
}

function computer_468x60()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- linux_468X60 -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:468px;height:60px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"2273569933\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function computer_link()
{

}
function gglink200x90(){
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- 200X90-11-06-13 -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:200px;height:90px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"7895355632\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function ad_300x250_h()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- ad_300x250_h -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:300px;height:250px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"9896965862\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function ad_300x250_i()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- ad_300x250_i -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:300px;height:250px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"2676469866\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function computer_970x90_j()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- ad_970x90_j -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:970px;height:90px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"7451419869\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function computer_970x90_k()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- ad_970x90_k -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:970px;height:90px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"1404886261\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}

function computer_970x90_l()
{
	document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
	document.writeln("<!-- ad_970x90_l -->");
	document.writeln("<ins class=\"adsbygoogle\"");
	document.writeln("     style=\"display:inline-block;width:970px;height:90px\"");
	document.writeln("     data-ad-client=\"ca-pub-1247408154976284\"");
	document.writeln("     data-ad-slot=\"5835085864\"><\/ins>");
	document.writeln("<script>");
	document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
	document.writeln("<\/script>");
}
