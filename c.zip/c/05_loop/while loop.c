#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    i=1;
    while(i<=50)
    {
        printf("%d \t", i);
        i+=2;
    }

}
