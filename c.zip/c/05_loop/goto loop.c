#include<stdio.h>
#include<conio.h>
void main()
{
    int i=1,j;
   do{
    if(i==5)
    {
        goto endloop;
    }
    printf("\n%d",i);
    i++;
    }
    while(i<=10);


    endloop:
        printf("\nhaha escap");
        printf("\ndev");
}
