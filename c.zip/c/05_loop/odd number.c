#include<stdio.h>
#include<conio.h>
void main()
{
    int n=20, i;
    for(i=1;i<=n;i++)
    {
        if(i%2!=0)
        {
            printf("\t%d",i);
        }
    }
}
