#include<stdio.h>
#include<conio.h>
void main()
{
    int n, i, mul;
    printf("Enter any number");
    scanf("%d",&n);

    for(i=1;i<=10;i++)
    {
        mul=n*i;
        printf("\n %d*%d=%d ",n,i,mul);


    }

}
