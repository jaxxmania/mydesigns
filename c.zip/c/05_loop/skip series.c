#include<stdio.h>
#include<conio.h>
void main()
{
int i, sum=0;
/*printf("Enter your number : ");
scanf("%d",&n);*/
for(i=1; i<=5; i++)
{
    if(i==3)
    {
        i++;
    }
printf("%d\t",i);
}
}
