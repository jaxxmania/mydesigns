#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    for(i=1;i<=5;i++)
    {
        printf("\nHello! world");
    }
        printf("\n\n\n");
    for(i=1;i<=500;i++)
    {
        printf("%d\t",i);
    }

}
