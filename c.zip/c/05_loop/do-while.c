#include<stdio.h>
#include<conio.h>
void main()
{
int i=1;
do
{
    printf("%d\t", i);
    i++;
}
while(i<=5);
}
