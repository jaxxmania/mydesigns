#include<stdio.h>
#include<conio.h>
void main()
{
int n, i, j, c=0;
printf("Enter your number : ");
scanf("%d",&n);
for(i=2; i<=n; i++)
{
    for(j=1; j<=i; j++)
    {
       if(i%j==0)
       {
           c++;
       }
    }
    if(c==2)
    printf("%d\t", i);
    c=0;
}
}
