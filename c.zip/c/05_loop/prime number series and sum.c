#include<stdio.h>
#include<conio.h>
void main()
{
int i, sum=0;
/*printf("Enter your number : ");
scanf("%d",&n);*/
for(i=1; i<=5; i++)
{
    printf("%d\t", i);
    sum=sum+i;
}
printf("\nTotal sum : %d",sum);
}
