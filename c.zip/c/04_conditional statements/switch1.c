#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    float n1, n2, sum, sub, mul, div;
    int op;
    printf("Enter  First Number:");
    scanf("%f",&n1);
    printf("Enter  Second Number:");
    scanf("%f",&n2);
    printf("Enter  Operater sign no.(1=+, 2=-,3=*, 4=/):");
    scanf("%d",&op);

    switch(op)
    {
    case 1:
        sum=n1+n2;
        printf("Sum:%f",sum); break;
    case 2:
        sub=n1-n2;
        printf("Subtract:%f",sub); break;
    case 3:
        mul=n1*n2;
        printf("Multiplication:%f",mul); break;
    case 4:
        div=n1/n2;
        printf("divid:%f",div); break;
    default:
        printf("Invalid Operator sign Please enter any sign of these '+, -, *, /'");
        break;
    }
    getch();
}
