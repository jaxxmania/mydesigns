#include<stdio.h>
#include<conio.h>
void main()
{
    char name[50];
    int age, choice;

    start:
    printf("\nEnter your Name : ");
    scanf("%s", &name);
    printf("\nEnter your Age : ");
    scanf("%d", &age);

    printf("\n\n\n*******************************");
    printf("\n****** Personal Details *******");
    printf("\n*******************************");

    printf("\n\n-------------------------------");
    printf("\n Name \t\t|\t Age");
    printf("\n-------------------------------");
    printf("\n%s\t\t|\t %d",name,age);
    printf("\n-------------------------------");

    printf("\n\nDo you want to add another one? [1 = Yes, otherwise = no] : ");
    scanf("%d",&choice);
    switch(choice)
    {
    case 1:
        goto start;
    default:
        printf("Program is Terminating... press any KEY\n\n");
    }
}
