#include<stdio.h>
#include<conio.h>
 main()
{
    float marks=30;

    if(marks>=35)
    {
        printf("You're Pass");
    }
    if(marks<35)
    {

        printf("You're Fail");
    }
}
