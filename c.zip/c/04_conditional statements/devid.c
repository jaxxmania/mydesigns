#include<stdio.h>
#include<conio.h>
void main()
{
   int num1, num2, op, sum=0, subs=0, mul=0, div=0;

   printf("Enter the value of first number : ");
   scanf("%d",&num1);
   printf("Enter the value of second number : ");
   scanf("%d",&num2);
   printf("Enter operator sign (1='+', 2='-', 3='*', 4='/') : ");
   scanf("%d",&op);
   switch(op)
   {
   case 1:
       sum=num1+num2;
    printf("Sum : %d", sum); break;
   case 2:
       subs=num1-num2;
    printf("Substract : %d", subs); break;
   case 3:
       mul=num1*num2;
    printf("Miltiplication : %d", mul); break;
   case 4:
       div=num1/num2;
    printf("divid : %d", div); break;
   default:
    printf("\a\aInvalid operator choice number !!"); break;
   }
}
