#include<stdio.h>
#include<conio.h>
void main()
{
    float income, expenditure, saving;

    printf("Enter your income value :Rs.");
    scanf("%f",&income);
    printf("Enter your expenditure value :Rs.");
    scanf("%f",&expenditure);
    if(income>expenditure)
    {
        saving=income-expenditure;
        printf("Saving :Rs.%f",saving);
    }
    else
    {
        saving=income-expenditure;
        printf("No saving %.0f",saving);
    }

getch();
}
