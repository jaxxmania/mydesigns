#include<stdio.h>
#include<conio.h>
void main()
{
    float nep=50, eng=50;
    float per, total=0;
    char name[]="Ram";
    if(nep>=35 && eng>=35)
    {
        total=nep+eng;
        per=total/2;
        printf("\nName :%s",name);
        printf("\nRemarks : Pass");
        printf("\nTotal Marks :%f\n",total);
        if(per>=75){printf("Divisition : Distinction");}
    else if(per>=60){printf("Divisition : First");}
    else if(per>=45){printf("Divisition : Second");}
    else{printf("Divisition : Pass");}
    }
    else
    {
        printf("Sorry !!!, You have been failed");
    }
}
