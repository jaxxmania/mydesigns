#include<stdio.h>
#include<conio.h>
void main()
{
    float n1, n2, sum, sub, mul, div;
    char op[2];
    printf("Enter  First Number:");
    scanf("%f",&n1);
    printf("Enter  Second Number:");
    scanf("%f",&n2);
    printf("Enter  Operater sign:");
    scanf("%s",&op);

    switch(op)
    {
    case 1:
        printf("Sun"); break;
    case 2:
        printf("Mon"); break;
    case 3:
        printf("Tue"); break;
    case 4:
        printf("Wed"); break;
    case 5:
        printf("Thu"); break;
    case 6:
        printf("Fri"); break;
    case 7:
        printf("Sat"); break;
    default:
        printf("Invalid day no.");
        break;
    }
    getch();
}
