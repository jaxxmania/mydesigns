#include<stdio.h>
#include<conio.h>
void main()
{
    int per=30;
    if(per>=75)
    {
        printf("Divisition : Distinction");
    }
    else if(per>=60)
    {
         printf("Divisition : First");
    }
    else if(per>=45)
    {
         printf("Divisition : Second");
    }
    else if(per>=35)
    {
         printf("Divisition : Pass");
    }
    else{
         printf("Fail");
    }
}
