#include<stdio.h>
#include<conio.h>
void main()
{
    float marks=40;

    if(marks>=35)
    {
        printf("You're Pass");
    }
    else{
        printf("You're Fail");}
}
