#include<stdio.h>
#include<conio.h>
void main()
{
    char name[50];
    int phone, cc, pc, tc;

    float tsc, vat, ta, extra_call, extra_amt, amt;

    printf("********************************************************************************");
    printf("********************************************************************************");
    printf("**************************** Welcome to NTC Bill *******************************");
    printf("********************************************************************************");
    printf("********************************************************************************");


    printf("\nEnter Customer name: ");
    scanf("%s",&name);
    printf("\nEnter Phone No.: ");
    scanf("%d",&phone);
    printf("\nEnter Current Call: ");
    scanf("%d",&cc);
    printf("\nEnter Previous Call: ");
    scanf("%d",&pc);

    tc=cc-pc;
    if(tc<=100)
    {
        tsc=180*10/100;
        vat=180*13/100;
        ta=180+tsc+vat;
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nCustomer Name :%s",name);
        printf("\nCustomer Phone No. :%d",phone);
        printf("\nTotal Call :%d",tc);
        printf("\nTotal Amount : Rs. 180");
        printf("\nTotal Service Charge (TSC) : Rs.%f",tsc);
        printf("\nVAT (13%) : Rs.%f",vat);
        printf("\nNet Total Amount : Rs.%f",ta);
    }
    else
    {
        extra_call=tc-100;
        extra_amt=extra_call*1.8;

        amt=180+extra_amt;
        tsc=amt*10/100;
        vat=amt*13/100;
        ta=amt+tsc+vat;
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nt\t\t\t\t\t\t\t\t\t\t\t\tCustomer Name :%s",name);
        printf("\nCustomer Phone No. :%d",phone);
        printf("\nTotal Call :%d",tc);
        printf("\nTotal Amount : Rs. %f",amt);
        printf("\nTotal Service Charge (TSC) : Rs.%f",tsc);
        printf("\nVAT (13%) : Rs.%f",vat);
        printf("\nNet Total Amount : Rs.%f",ta);
    }

        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t\t\t\t\tThank you for using our service");

    //getch();
}
