#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
    for(i=1; i<=5; i++)
    {
        if(i==3)
        {
            goto end;
        }
        printf("\nNumber : %d",i);
    }
    end:
    printf("\nThis is end section");
}
