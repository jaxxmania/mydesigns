#include<stdio.h>
#include<conio.h>
void main()
{
    float nepali=70, math=20, english=60;

    if(nepali>=35 && math>=35 && english>=35)
    {
        printf("You're Pass");
    }
    else{printf("You're Fail");}
}
