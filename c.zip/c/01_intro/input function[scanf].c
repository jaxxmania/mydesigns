#include<stdio.h>
#include<conio.h>
void main()
{
    char name[50];
    char address[50];
    int age;

    printf("\nEnter your name : ");
    scanf("%s",&name);
    printf("\nEnter your address : ");
    scanf("%s",&address);
    printf("\nEnter your age : ");
    scanf("%d",&age);


    printf("\n\n\nName : = %s",name);
    printf("\n\nAddress : = %s",address);
    printf("\n\nAge : = %d",age);
    getch();
}
