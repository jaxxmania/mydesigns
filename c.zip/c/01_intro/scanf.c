#include<stdio.h>
#include<conio.h>
void main()
{
int x, y, sum;
char name[10];


    printf("\n Enter the number of x");
    scanf("%d",&x);

    printf("\n Enter the number of y");
    scanf("%d",&y);

    sum=x+y;

    printf("\n sum:%d",sum);

    printf("\n Enter you name");
    scanf("%s",&name);

    printf("\n Name: %s",name);

}
