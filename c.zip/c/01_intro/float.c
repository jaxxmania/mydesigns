#include<stdio.h>
#include<conio.h>
void main()
{
    double x=1.23456789;
    float y=1.23456789;

    long double sum=x+y;

    printf("\n x: %f",x);
    printf("\n y: %.7f",y);
    getch();

}
