#include<stdio.h>
#include<conio.h>
void main()
{
    int a=15;
    int b=5;
    int sum= a+b;
    printf("\n %d",sum);
    getch();

}
