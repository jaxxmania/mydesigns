#include<stdio.h>
#include<conio.h>
void main()
{
    FILE *f;
    int a[2];

    f=fopen("num.dat","w");


}
