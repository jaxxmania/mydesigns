#include<stdio.h>
#include<conio.h>
void main()
{
/*for print personal details*/
    printf("My name is Ram");
    printf("I'm 18 years old.");
    printf("i'm form kathmandu.");
    getch();

   int doo=5;
   char
}
