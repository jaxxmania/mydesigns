#include<stdio.h>
#include<conio.h>
#define name "Aptech"
#define col 2
 main()
{
    char nam[20];

    printf("%d",col);

}
