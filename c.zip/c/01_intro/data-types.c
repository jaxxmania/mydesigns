#include<stdio.h>
#include<conio.h>
void main()
{
    int a=5;
    float b=10.5;
    char c='A';
    char city[]="Kathmandu";


    printf("\nInteger value of a = %d",a);
    printf("\nFloating value of b = %f",b);
    printf("\nCharecter value of c = %c",c);
    printf("\nCity name = %s",city);
    getch();
}
