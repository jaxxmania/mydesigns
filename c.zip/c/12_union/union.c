#include<stdio.h>
#include<conio.h>
union Book{
int price;
float id;
};
void main()
{
    union Book b;
    b.price=450;
    b.id=15023.45;
    printf("Book price : %d", b.price);
    printf("Book id : %f", b.id);


}
