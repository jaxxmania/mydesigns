#include<stdio.h>
#include<conio.h>
union Book{
int price;
float id;
};
void main()
{
    union Book b;
    printf("size of union :%u",sizeof(b));


}
