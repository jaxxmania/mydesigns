#include<stdio.h>
#include<conio.h>
int fact(int);
void main()
{
    int x, z;
    printf("Enter the value of x :");
    scanf("%d",&x);
    z=fact(x);
    printf("\nFactorial value of %d : %d\n",x, z);
}
int fact(int x)
{
    int f;
    if(x<=1)
    {
        return 1;
    }
    else
    {
        f=fact(x-1);
        return (x*f);
    }
}
