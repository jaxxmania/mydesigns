/*  function passing  no parameter and return value */
#include<stdio.h>
#include<conio.h>
int add(int, int, int);
int main()
{
    int c=add(10,5,5);
    printf("Sum: %d",c);


    return 0;
    getch();
}
int add(int x, int y, int z)
{
    int sum=0;
    sum=x+y+z;
    return sum;
}

