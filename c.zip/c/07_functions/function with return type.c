#include<stdio.h>
#include<conio.h>
int sum();
void main(){
    int z=sum();
    printf("Total sum: %d",sum());
}
int sum()
{
    int x=40, y=10, sum=0;
    sum=x+y;
    return sum;
}


