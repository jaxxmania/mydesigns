#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    int len;
    char name[]="APTECH";
    len=strlen(name);
    printf("String Length : %d",len);
}
