#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main()
{
    int static i=1;
    printf("\nRecursion\n");
    i++;
    if(i<=4)
    {
        main();
    }
    else
    {
        exit;
    }
}
