/*function with return value*/
#include<stdio.h>
#include<conio.h>
int add(int, int);
void main()
{
    int c=add(6,6);
    printf("sum:%d", c);
}
int add(int x, int y)
{
    int sum;
    sum=x+y;
    return sum;
}
