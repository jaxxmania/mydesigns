/*function with return value*/
#include<stdio.h>
#include<conio.h>
char add(char[5], char[5]);
void main()
{
    char c[]=add(6,6);
    printf("sum:%s", c);
}
char add(char x[5], char y[5])
{
    char sum;
    sum=x[5]+y[5];
    return sum;
}
