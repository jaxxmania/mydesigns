#include<stdio.h>
#include<conio.h>
int swap_fun(int, int);
int main()
{
    int x, y;
    printf("Enter value of x:");
    scanf("%d",&x);
    printf("Enter value of y:");
    scanf("%d",&y);

    printf("\nOriginal value of x=%d \t y=%d",x,y);
    printf("\n\n\n");
    swap_fun(x,y);
}
int swap_fun(int x, int y)
{
    int a;
    a=x;
    x=y;
    y=a;

    printf("After swaping function value of x=%d \t y=%d",x,y);
}
