/*  function passing  parameter and no return value */
#include<stdio.h>
#include<conio.h>
void add(int, int);
int main()
{
    add(50,60);
    return 0;
    getch();
}
void add(int x, int y)
{
    int sum=0;
    sum=x+y;
    printf("Sum:%d",sum);
}

