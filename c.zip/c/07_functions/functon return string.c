/*function with return value*/
#include<stdio.h>
#include<conio.h>
char info();
void main()
{
    char c[5]=info();
    printf("Name:%d", c);
}
char info()
{
    char name[50]="dev";
    return name[5];
}
