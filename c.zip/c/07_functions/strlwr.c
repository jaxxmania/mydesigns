#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char name[]="APTECH";
    strlwr(name);
    printf("Name : %s",name);
}
