#include<stdio.h>
#include<conio.h>
int price(int x, int y);
void main()
{
    int z, p, q;
    printf("Enter you First Price Rs.:");
    scanf("%d",&p);
    printf("Enter you Second Price Rs.:");
    scanf("%d",&q);
    z=price(p, q);
    printf("Sum of Price : %d",z);
}
int price(int x, int y)
{
    int sum=0;
    sum=x+y;
    return sum;
}
