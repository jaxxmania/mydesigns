#include<stdio.h>
#include<conio.h>
void main()
{
    int x, y, z;
    printf("Enter the value of x : ");
    scanf("%d",&x);
    printf("Enter the value of y : ");
    scanf("%d",&y);

    printf("\n\nOriginal value of x =%d, y = %d", x,y);
    z=x;
    x=y;
    y=z;
    printf("\n\nAfter swaping value of x =%d, y = %d", x,y);

}
