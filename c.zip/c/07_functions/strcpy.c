#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char source[]="Kathmandu";
    char target[50];
    strcpy(target, source);
    printf("City Name : %s",target);
}
