/*  function passing  no parameter and return value */
#include<stdio.h>
#include<conio.h>
int add();
int main()
{
    int c=add();
    printf("Sum: %d",c);


    return 0;
    getch();
}
int add()
{
    int x, y, sum=0;
    printf("\nEnter first Number:");
    scanf("%d",&x);
    printf("\nEnter second Number:");
    scanf("%d",&y);
    sum=x+y;

    return sum;
}

