#include<stdio.h>
#include<conio.h>
void person();
void main()
{
    person();
}
void person()
{
    char name[40];
    char address[50];
    int age;

    printf("Enter your name : ");
    scanf("%s",&name);
    printf("Enter your address : ");
    scanf("%s",&address);
    printf("Enter your age : ");
    scanf("%d",&age);

    printf("\n\n\n---------------------------");
    printf("\n----------Personal Details----------");
    printf("\n---------------------------");
    printf("\n\nName : %s",name);
    printf("\nAddress : %s",address);
    printf("\nAge : %d",age);
}
