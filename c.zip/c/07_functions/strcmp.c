#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    int a,b,c;
    char name[]="Ram";
    char city[]="ktm";
    char person[]="Ram";
    a=strcmp(name,city);
    b=strcmp(name, person);

    printf("un-Equal String : %d",a);
    printf("\nEqual String : %d",b);
}
