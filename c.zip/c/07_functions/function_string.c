/*  function passing no parameter and no return value */
#include<stdio.h>
#include<conio.h>
void info();
int main()
{
    info();
    return 0;
    getch();
}
void info()
{
    char name[50], address[50];
    printf("Enter name:");
    scanf("%s",&name);
    printf("Enter address:");
    scanf("%s",&address);
    printf("Name: %s \n Address: %s",name,address);
}
