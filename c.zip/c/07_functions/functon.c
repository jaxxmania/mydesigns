/*function with return value*/
#include<stdio.h>
#include<conio.h>
int add();
void main()
{
    int c=add();
    printf("sum:%d", c);
}
int add()
{
    int x=10, y=5, sum;
    sum=x+y;
    return sum;
}
