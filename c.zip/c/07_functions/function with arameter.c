#include<stdio.h>
#include<conio.h>
void sum(int x, int y);
void main(){
    sum(150,90);
}
void sum(int x, int y)
{
    int sum=0;
    sum=x+y;
    printf("Total sum : %d", sum);
}


