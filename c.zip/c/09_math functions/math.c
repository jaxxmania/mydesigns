#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{
int x, y;
printf("\nEnter number :");
scanf("%d",&x);

//y=pow(x,2);
//y=cbrt(x);
y=sqrt(x);

printf("Result %d:",y);
}
