<h3 class="page-header">Insert Post For Home</h1>

	<form name="insert_home" method="POST">

			<div class="form-group">
				  <label for="PostTitle">Post Title</label>

				  <input type="text" name="post_title" class="form-control" placeholder="Type your content" required/>

			</div>

			<div class="form-group">
				 <label for="PostDescription">Post Description</label>

				 <textarea name="post_description" class="form-control"></textarea>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Create Post For Home</button>

			</div>

	</form>
	<?php
  include('../include/connect.php');
		if(isset($_POST['btn_submit']))
		{
		$title=$_POST['post_title'];
		$desc=$_POST['post_description'];
		//SQl Query to insert data 
$sql="insert into tblHome(title,description)values('$title','$desc')";
 $qry=mysqli_Query($con,$sql);
if($qry)
  {
     echo "<script>alert('Record Submitted Successfully')</script>";
    }
}
?>