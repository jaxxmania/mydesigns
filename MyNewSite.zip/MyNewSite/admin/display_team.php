<h3 class="page-header">Display Post For Team</h3>
<table class="table table-bordered table-responsive">
	 <tr class="bg-primary">
	 	 <th>S.No</th>
	 	 <th>Title</th>
	 	 <th>Designation</th>
	 	 <th>Image</th>
	 	 <th>Edit</th>
	 	 <th>Delete</th>
	 </tr>
	<?php 
		include('../include/connect.php');
		$sql="select *from tblteam order by id";
		$qry=mysqli_query($con,$sql);
		$i=0;
		while($row=mysqli_fetch_array($qry))
		{
			$id=$row['id'];
			$title=$row['title'];
			$img=$row['image'];
			$desc=$row['designation'];
			$i++;
		   ?>
	   <tr class="bg-info">
	   		<td><?php echo $id;?></td>
	   		<td><?php echo $title;?></td>
	   		<td><?php echo $desc;?></td>
	   		<td><?php echo "<img src='../images/$img' width=200 height=200 />";?></td>
	   		<td><a href="index.php?edit_team=<?php echo $id;?>" class="btn btn-primary">Edit</a></td>
	   		<td><a href="delete_team.php?delete_team=<?php echo $id;?>" class="btn btn-primary">Delete</a></td>
	   </tr>
	   <?php 
	}?>


</table>