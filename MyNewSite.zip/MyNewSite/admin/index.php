<!doctype html>
  <html lang="en">
     <head>
     		<meta charset="UTF-8"/>

     		<title>Project Title- Main HomePage</title>

     		<meta name="viewport" content=width="device-width, initial-scale=1.0"/>
     		<link rel="stylesheet" type="text/css" href="../css/style.css"/>
     		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css"/>
     		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="../fontawesome/css/all.css"/>
        <link rel="stylesheet" type="text/css" href="../fontawesome/css/all.min.css"/>
     </head>
     <body>
     	  <h1 class="page-header">Welcome to Admin Panel</h1>
          
          <div class="container-fluid">
          	 <div class="row">
             	  <div class="col-md-4">
                  			 	<h3 class="bg-primary"><i class="glyphicon glyphicon-home"></i> Home</h3>
                                <ul class="list-group">
                                	 <li class="list-group-item">
                                     <a href="index.php?create_home"> <i class="fas fa-file"></i>  Create</a></li>
                                 <li class="list-group-item"><a href="index.php?display_home"> <i class="fas fa-eye"></i> View</a></li>
                                </ul>
                                <h3 class="bg-primary"><i class="glyphicon glyphicon-bullhorn"></i> About</h3>
                                <ul class="list-group">
                                   <li class="list-group-item">
                                     <a href="index.php?create_about"> <i class="fas fa-file"></i>  Create</a></li>
                                 <li class="list-group-item"><a href="index.php?display_about"> <i class="fas fa-eye"></i> View</a></li>
                                </ul>
                                <h3 class="bg-primary"><i class="glyphicon glyphicon-wrench"></i> Services</h3>
                                <ul class="list-group">
                                   <li class="list-group-item">
                                     <a href="index.php?create_service"> <i class="fas fa-file"></i>  Create</a></li>
                                 <li class="list-group-item"><a href="index.php?display_service"> <i class="fas fa-eye"></i> View</a></li>
                                </ul>

                              <h3 class="bg-primary"><i class="fas fa-users"></i> Manage Team</h3>
                              <ul class="list-group">
                                  <li class="list-group-item">
                                    <a href="index.php?create_team">
                                      <i class="fas fa-file"></i> Create</a></li>
                                      <li class="list-group-item">
                                    <a href="index.php?display_team">
                                      <i class="fas fa-eye"></i> View</a></li>


                              </ul>
                               
                  </div>
                  
                  <div class="col-md-8">
                  				<h2><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h2>

                          <?php

                            if(isset($_GET['create_home']))
                            {
                              include('create_home.php');
                            }
                            if(isset($_GET['display_home']))
                            {
                              include('display_home.php');
                            }
                            if(isset($_GET['edit_home']))
                            {
                              include('edit_home.php');
                            }
                            if(isset($_GET['delete_home']))
                            {
                              include('delete_home.php');
                            }
                            if(isset($_GET['create_about']))
                            {
                              include('create_about.php');
                            }
                            if(isset($_GET['display_about']))
                            {
                              include('display_about.php');
                            }
                            if(isset($_GET['edit_about']))
                            {
                              include('edit_about.php');
                            }
                            if(isset($_GET['delete_about']))
                            {
                              include('delete_about.php');
                            }
                            if(isset($_GET['create_service']))
                            {
                              include('create_service.php');
                            }
                            if(isset($_GET['display_service']))
                            {
                              include('display_service.php');
                            }
                            if(isset($_GET['edit_service']))
                            {
                              include('edit_service.php');
                            }
                            if(isset($_GET['delete_service']))
                            {
                              include('delete_service.php');
                            }
                            if(isset($_GET['create_team']))
                            {
                              include('create_team.php');
                            }
                            if(isset($_GET['display_team']))
                            {
                              include('display_team.php');
                            }
                            if(isset($_GET['edit_team']))
                            {
                              include('edit_team.php');
                            }
                            if(isset($_GET['delete_team']))
                            {
                              include('delete_team.php');
                            }

                          ?>
                  </div>
             
             </div>
          
          </div>

     	  <!--footer section ends here-->
        <!--Latest and mninfied version jquery-->
        <script src="../js/jquery-3.3.1.min.js"></script>
        <script src="../bootstrap/js/bootstrap.min.js"></script>
     </body>
  </html>