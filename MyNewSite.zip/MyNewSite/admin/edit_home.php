<?php

	include('../include/connect.php');
	if(isset($_GET['edit_home']))
	{

	$edit_id=$_GET['edit_home'];

	$sql="select *from tblhome where id='$edit_id'";

	$qry=mysqli_query($con,$sql) or die(mysqli_error());

	$row=mysqli_fetch_array($qry);

	$post_id=$row['id'];

	$title=$row['title'];
	$desc=$row['description'];

	}

?>


<h3 class="page-header">Edit Post For Home</h1>

	<form name="insert_home" method="POST">

			<div class="form-group">
				  <label for="PostTitle">Post Title</label>

				  <input type="text" name="post_title" class="form-control" placeholder="<?php echo $title;?>" required/>

			</div>

			<div class="form-group">
				 <label for="PostDescription">Post Description</label>

				 <textarea name="post_description" class="form-control">
				 	
				 	<?php echo  $desc;?>
				 </textarea>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Edit Post For Home</button>

			</div>

	</form>
	
	<?php
include('../include/connect.php');
  if(isset($_POST['btn_submit']))
  {
  	$update_id=$post_id;
  	$home_title=$_POST['post_title'];
  	$home_desc=$_POST['post_description'];
  	$home_sql="update tblhome set title='$home_title',description='$home_desc' where id='$update_id'";
  	$home_qry=mysqli_query($con,$home_sql);
  	
  		if($home_qry)
  		{
  			echo "<script>alert('Record Updated Successfully')</script>";
  			echo "<script>window.open('index.php?display_home','_self');</script>";
  		}
  	

  }



	?>