<?php
	   include('../include/connect.php');
	   if(isset($_GET['edit_about']))
	   {


	   	$about_id=$_GET['edit_about'];
	 	$about_sql="select *from tblabout where id='$about_id'";
	 	$about_qry=mysqli_query($con,$about_sql);
	 	$about_row=mysqli_fetch_array($about_qry);
	 	$aboutid=$about_row['id'];
	 	$abouttitle=$about_row['title'];
	 	$aboutdesc=$about_row['description'];
	   }
?>
<h3 class="page-header">Edit Post For About</h1>
	<form name="insert_about" method="POST">
			<div class="form-group">
			  <label for="PostTitle">Post Title</label>
			  <input type="text" name="post_title" class="form-control" placeholder="<?php echo $abouttitle;?>"required/>

			</div>

			<div class="form-group">
				 <label for="PostDescription">Post Description</label>

				 <textarea name="post_description" class="form-control">
				 	
				 	<?php echo $aboutdesc;?>
				 </textarea>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Edit Post For About</button>

			</div>

	</form>

	<?php
	   include('../include/connect.php');
	   if(isset($_POST['btn_submit']))
	   {
		$update_id=$about_id;
		$title=$_POST['post_title'];
		$desc=$_POST['post_description'];
		$sql="update tblabout set title='$title',description='$desc' where id='$update_id'";
		$qry=mysqli_query($con,$sql);
		if($qry)
		 {
		  echo "<script>alert('Record updated')</script>";
	echo "<script>window.open('index.php?display_about','_self')</script>";
		}

	   }

	?>

