<?php 
		include('../include/connect.php');
		if(isset($_GET['edit_team']))
		{

			$get_id=$_GET['edit_team'];

			$sql="select *from tblteam where id='$get_id'";

			$qry=mysqli_query($con,$sql);

			$row=mysqli_fetch_array($qry);

			$update_id=$row['id'];
			$title=$row['title'];
			$img=$row['image'];

			$desc=$row['designation'];

		}
		
		?>

<h3 class="page-header">Edit Post For Team</h1>

	<form name="edit_team" method="POST" enctype="multipart/form-data">

			<div class="form-group">
				  <label for="PostTitle">Post Title</label>

				  <input type="text" name="post_title" class="form-control" placeholder="<?php echo $title;?>" required/>

			</div>

			<div class="form-group">
				 <label for="PostImage">Post Image</label>

				 <input type="file" class="form-control" name="post_image"/>


			</div>

			<br/><br/>

			<?php echo "<img src='../images/$img' class='img-thumbnail'/>";?>
			<div class="form-group">
				  <label for="PostTitle">Post Designation</label>

				  <input type="text" name="post_designation" class="form-control" placeholder="<?php echo $desc;?>" required/>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Edit Post For Home</button>

			</div>

	</form>
	<?php

	
  include('../include/connect.php');
		if(isset($_POST['btn_submit']))

		{
		 $team_id=$update_id;
		 $teamtitle=$_POST['post_title'];
		 $teamimg=$_FILES['post_image']['name'];
		 $teamimg_tmp=$_FILES['post_image']['tmp_name'];
		 $teamdesg=$_POST['post_designation'];

		 move_uploaded_file($teamimg_tmp,"../images/$teamimg");
		 $teamsql="update tblteam set title='$teamtitle',image='$teamimg',designation='$teamdesg' where id='$team_id'";
		 $teamqry=mysqli_query($con,$teamsql);
		 if($teamqry)
		 {
		 	echo "<script>alert('Record updated Successfully')</script>";
		 	echo "<script>window.open('index.php?display_team','_self')</script>";
		 }
	}
?>
		