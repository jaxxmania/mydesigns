<h3 class="page-header">Insert Post For Team</h1>

	<form name="insert_team" method="POST" enctype="multipart/form-data">

			<div class="form-group">
				  <label for="PostTitle">Post Title</label>

				  <input type="text" name="post_title" class="form-control" placeholder="Type your content" required/>

			</div>

			<div class="form-group">
				 <label for="PostImage">Post Image</label>

				 <input type="file" class="form-control" name="post_image"/>
			</div>
			<div class="form-group">
				  <label for="PostTitle">Post Title</label>

				  <input type="text" name="post_designation" class="form-control" placeholder="Type your content" required/>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Create Post For Home</button>

			</div>

	</form>
	<?php
	
  include('../include/connect.php');
		if(isset($_POST['btn_submit']))
		{
		 $title=$_POST['post_title'];
		 $img=$_FILES['post_image']['name'];
		 $img_tmp=$_FILES['post_image']['tmp_name'];
		 $desg=$_POST['post_designation'];

		 move_uploaded_file($img_tmp,"../images/$img");
		 $sql="insert into tblteam(title,image,designation)values('$title','$img','$desg')";
		 $qry=mysqli_query($con,$sql);
		 if($qry)
		 {
		 	echo "<script>alert('Record Inserted Successfully')</script>";
		 }
	}
?>
		