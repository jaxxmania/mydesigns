<?php

include("../include/connect.php");
 if(isset($_GET['delete_home']))
 {
$del_id=$_GET['delete_home'];
$sql="delete from tblhome where id='$del_id'";
$qry=mysqli_query($con,$sql) or die(mysqli_error());
if($qry)
{
	echo "<script>alert('Record has been deleted')</script>";
	echo "<script>window.open('index.php?display_home','_self')</script>";
}
}

	



?>


