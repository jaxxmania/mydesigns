<?php

	   include('../include/connect.php');
	   if(isset($_GET['edit_service']))
	   {


	   	$service_id=$_GET['edit_service'];
	 	$service_sql="select *from tblservice where id='$service_id'";
	 	$service_qry=mysqli_query($con,$service_sql);
	 	$service_row=mysqli_fetch_array($service_qry);
	 	$serviceid=$service_row['id'];
	 	$servicetitle=$service_row['title'];
	 	$serviceicon=$service_row['icon'];
	 	$servicedesc=$service_row['description'];
  }
?>
<h3 class="page-header">Edit Post For Serice</h1>
	<form name="insert_about" method="POST">
			<div class="form-group">
			  <label for="PostTitle">Post Title</label>
			  <input type="text" name="post_title" class="form-control" placeholder="<?php echo $servicetitle;?>"required/>

			</div>
			<div class="form-group">
			  <label for="PostIcon">Post Icon</label>
			  <input type="text" name="post_icon" class="form-control" placeholder="<?php echo $serviceicon;?>"required/>

			</div>

			<div class="form-group">
				 <label for="PostDescription">Post Description</label>

				 <textarea name="post_description" class="form-control">
				 	<?php echo $servicedesc;?>
				 	
				 </textarea>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Edit Post For About</button>

			</div>

	</form>

	<?php
	   include('../include/connect.php');
	   if(isset($_POST['btn_submit']))
	   {
		$update_id=$service_id;
		$title=$_POST['post_title'];
		$icon=$_POST['post_icon'];
		$desc=$_POST['post_description'];
		$sql="update tblsercice set title='$title',icon='$icon', description='$desc' where id='$update_id'";
		$qry=mysqli_query($con,$sql);
		if($qry)
		 {
		  echo "<script>alert('Record updated')</script>";
	echo "<script>window.open('index.php?display_service','_self')</script>";
		}

	   }

	?>

