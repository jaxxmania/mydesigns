<h3 class="page-header">Insert Post For About</h1>

	<form name="insert_about" method="POST">

			<div class="form-group">
				  <label for="PostTitle">Post Title</label>

				  <input type="text" name="post_title" class="form-control" placeholder="Type your content" required/>

			</div>

			<div class="form-group">
				 <label for="PostDescription">Post Description</label>

				 <textarea name="post_description" class="form-control"></textarea>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Create Post For About</button>

			</div>

	</form>

	<?php
	
  include('../include/connect.php');
if(isset($_POST['btn_submit']))
		{
		 $title=$_POST['post_title'];
		 $desc=$_POST['post_description'];
		 $sql="insert into tblabout(title,description) values('$title','$desc')";
		 $qry=mysqli_query($con,$sql);
		 if($qry)
		 {
		 	echo "<script>alert('Record Inserted')</script>";
		 }
		}
?>