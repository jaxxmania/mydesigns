<h3 class="page-header">Insert Post For Service</h1>

	<form name="insert_service" method="POST">

			<div class="form-group">
				  <label for="PostTitle">Post Title</label>

				  <input type="text" name="post_title" class="form-control" placeholder="Type your content" required/>

			</div>
			<div class="form-group">
				  <label for="PostIcon">Post Icon</label>

				  <input type="text" name="post_icon" class="form-control" placeholder="Place icon" required/>

			</div>
			<div class="form-group">
				 <label for="PostDescription">Post Description</label>

				 <textarea name="post_description" class="form-control"></textarea>

			</div>

			<div class="form-group">
				 <button type="submit" name="btn_submit" class="btn btn-primary">Create Post For Service</button>

			</div>

	</form>
	<?php
		 include("../include/connect.php");
		 $title=$_POST['post_title'];
		 $icon=$_POST['post_icon'];
		 $desc=$_POST['post_description'];
		 $sql="insert into tblservice(title,icon,description) values('$title','$icon','$desc')";
		 $qry=mysqli_query($con,$sql);
		 if($qry)
		 {
		 	echo "<script>alert('Record Submitted')</script>";
		 }


	?>

	