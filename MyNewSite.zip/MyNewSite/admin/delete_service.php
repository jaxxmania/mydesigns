<?php
	   include('../include/connect.php');
	   if(isset($_GET['delete_service']))
	   {
	   	$del_id=$_GET['delete_service'];
	 	$sql="delete from tblservice where id='$del_id'";
	 	$qry=mysqli_query($con,$sql);
	 	if($qry)
	 	{
	 		echo "<script>alert('Record Deleted')</script>";
	 		echo "<script>window.open('index.php?display_service','_self')</script>";
	 	}
	   }
?>

