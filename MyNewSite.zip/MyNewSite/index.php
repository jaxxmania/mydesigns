
<?php include('functions/function.php');?>
<!doctype html>
  <html lang="en">
     <head>
     		<meta charset="UTF-8"/>

     		<title>Project Title- Main HomePage</title>

     		<meta name="viewport" content=width="device-width, initial-scale=1.0"/>
     		<link rel="stylesheet" type="text/css" href="css/style.css"/>
     		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"/>
     		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css"/>
        <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css"/>
     </head>
     <body>
     	<!--header section starts here-->
     	  <?php include('include/header.php');?>
     	  <!--header section ends here-->
        <?php include('include/profile.php');?>
     	  <!--Main Content starts here-->
     	  <!--Main Content ends here-->
        <!--service section starts here-->
        <?php include('include/services.php');?>
        <!--service section ends here-->
        <!--Our Team Section Starts Here-->
        <?php include('include/team.php');?>
        <!--Our Team Section Ends Here-->
        <!--Blog section Starts here-->
        <?php include('include/blog.php');?>  
        <!--Blog Section Ens Here-->
        <!-- Contact Info starts here-->
        <?php include('include/contact.php');?>
        <!--Contact Info ends here-->
         

   	  <!--footer section starts here-->
       <?php include('include/footer.php');?>
     	     </body>
  </html>