<?php

  $server="localhost";
  $user="root";
  $pass="";
  $db="mynewsite_db";
  $con=mysqli_connect($server,$user,$pass) or die(mysqli_error());
  mysqli_select_db($con,$db) or die(mysqli_error());



?>