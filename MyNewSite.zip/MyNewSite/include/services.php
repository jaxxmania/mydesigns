<section class="service_bg">
                    <div class="container  text-center">
                              <h3 id="Service">Our Services</h3>

                              <div class="row">

                                   <div class="col-md-4">

                                         <div class="panel panel-default">
                                              <h4>Web Development & Hosting</h4>
                                              <i class="fas fa-globe icons"></i>

                                              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.</p>

                                         </div>
                                   </div>
                                   <div class="col-md-4">

                                         <div class="panel panel-default">
                                              <h4>Apps Development</h4>
                                                <i class="fas fa-laptop icons"></i>
                                              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.</p>

                                         </div>
                                   </div>
                                   <div class="col-md-4">

                                         <div class="panel panel-default">
                                              <h4>Multimedia Solutions</h4>
                                               <i class="fas fa-video icons"></i>

                                              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.</p>

                                         </div>
                                   </div>


                              </div>

                    </div>

            </section>