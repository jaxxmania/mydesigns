 <section class="team_bg">

                    <div class="container text-center">
                                  <h3> Our Team  </h3>


                                  <div class="row">

                                     <div class="col-md-4">

                                          <h5 class="description">Jenish Sthapit</h5>
                                          <img src="images/team2.jpg" class="img-circle img-responsive"/>



                                          <p class="description">Web Developer  </p>

                                     </div>
                                     <div class="col-md-4">

                                          <h5 class="description">Jenish Sthapit</h5>
                                          <img src="images/team2.jpg" class="img-circle img-responsive"/>



                                          <p class="description">Web Developer  </p>

                                     </div>

                                        <div class="col-md-4">

                                          <h5 class="description">Jenish Sthapit</h5>
                                          <img src="images/team2.jpg" class="img-circle img-responsive"/>



                                          <p class="description">Web Developer  </p>
                                     </div>
                                  </div>
                    </div>

               </section>