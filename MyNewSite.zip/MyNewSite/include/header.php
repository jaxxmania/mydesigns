<header>

                <nav class="navbar navbar-change navbar-fixed-top" id="mynavbar">
                         <div class="container">

                               <div class="navbar-header">
                                   <button  type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                                         <span class="icon-bar"></span>
                                         <span class="icon-bar"></span>
                                         <span class="icon-bar"></span>

                                   </button>

                                   <a class="navbar-brand" href="#">MKS</a>

                               </div>

                               <div class="collapse navbar-collapse" id="navbar-collapse">

                                     <ul class="nav navbar-nav pull-right">
                                             <li><a href="#Home"><i class="fas fa-home">
                                             </i> Home</a></li>
                                             <li><a href="#About">About</a></li>
                                             <li><a href="#Service">Service</a></li>
                                             <li><a href="#Blog">Blog</a></li>
                                             <li><a href="#Contact">Contact</a></li>

                                     </ul>


                              </div>


                         </div>


                </nav>
                              <h1 class="marketing text-center">MKS Design & Animation</h1>
                              <p class="slogan text-center">Web Development | Multimedia  | ICT Support</p>

                              <a href="#" class="btn btn-danger know-more">Know More</a>

     	  </header>