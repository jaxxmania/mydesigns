 <section class="blog_section" id="Blog">

                  <div class="container">
                                  <h3 class="text-center">Blog Section</h3>
                                  <div class="row text-center">
                                      <div class="col-md-4">
                                          <div class="panel panel-default">
                                                <h5 class="text-danger">New Trends in Web Development</h5>

                                                <img class="img-thumbnail img-responsive" src="images/third.jpg"/>
                                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.
                                          </div>

                                      </div>
                                       <div class="col-md-4">
                                          <div class="panel panel-default">
                                                <h5 class="text-danger">UI/UX Design as New Career</h5>

                                                <img class="img-thumbnail img-responsive" src="images/third.jpg"/>
                                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.</p>
                                          </div>

                                      </div>
                                       <div class="col-md-4">
                                          <div class="panel panel-default">
                                                <h5 class="text-danger">laravel-The Best PHP Framework</h5>

                                                <img class="img-thumbnail img-responsive" src="images/second.jpg"/>
                                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.
                                          </div>

                                      </div>
                                  </div>

                  </div>
               </section>