<section>

     	  	<!--profile section starts here-->
     	  	  <div class="container text-center">
                              <?php displayHome();?>

                              

     	  	  		<div class="row">

     	  	  			  <div class="col-md-4" id="About">

     	  	  			  		<h3 class="profile">Who Are We?</h3>

                        <i class="fas fa-bullhorn icons"></i>
     	  	  			  		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.</p>

     	  	  			  </div>
     	  	  			   <div class="col-md-4">

     	  	  			  		<h3 class="profile">What We Have?</h3>
                        <i class="fas fa-cogs icons"></i>
     	  	  			  		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.</p>

     	  	  			  </div>
     	  	  			   <div class="col-md-4">

     	  	  			  		<h3 class="profile">Why With Us?</h3>
                         <i class="fas fa-handshake icons"></i>
     	  	  			  		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.</p>

     	  	  			  </div>

     	  	  		</div>

     	  	  </div>

     	  	  <!--profile section ends here-->

     	  </section>