<footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3">
                        <ul> 
                            <li><a href="#">Contact Info</a></li>
                            <li><a href="#"><i class="fas fa-home"></i> MKS</a></li>
                            <li><a href="#"><i class="fas fa-envelope"></i> info@mksdesigns.com</a></li>
                            <li><a href="#"><i class="fas fa-phone"></i> +977-01-5539522</a></li>
                            <li><a href="#"><i class="fas fa-globe"></i> www.mksdesign.com</a></li>


                        </ul>

                    </div>
                    <div class="col-md-3">

                        <ul>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Privacy Policy</a><li>

                        </ul>

                    </div>
                    <div class="col-md-3">

                        <ul>
                            <li><a href="#">Job Placement</a></li>
                            <li><a href="#">Training</a><li>

                        </ul>

                    </div>
                     <div class="col-md-3">

                        <h6>Get Connected with Us</h6>

                          <ul class="list-inline">
                            <li><a href="#"><i class="fab fa-facebook-square"></i></a><li>
                            <li><a href="#"><i class="fab fa-twitter-square"></i></a><li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a><li>
                            <li><a href="#"><i class="fab fa-youtube"></i></a></li>

                        </ul>

                    </div>



                </div>


            </div>


     	  </footer>	
        <footer class="copyright">
             <p>&copy; Copyright and Design:MKS Designs, 2018</p>


        </footer>

     	  <!--footer section ends here-->
        <!--Latest and mninfied version jquery-->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>