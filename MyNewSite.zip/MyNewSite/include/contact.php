<section class="contact_info">
    <div class="container">
             <h3 class="text-center">Get In Touch With Us</h3>
              <div class="row">

                 <div class="col-md-6">

             <form role="form" class="form-horizontal" method="POST">

                  <div class="form-group">

                      <label for="Name" class="control-label col-sm-3"> Name</label>

                      <div class="col-sm-9">
                         <input type="text" name="your_name" class="form-control" placeholder="Type your name" required/>

                      </div>


                  </div>
                  <div class="form-group">

                      <label for="Email" class="control-label col-xs-3">Email address</label>

                      <div class="col-xs-9">
                         <input type="email" name="your_name" class="form-control" placeholder="Type your name" required/>

                      </div>


                  </div>
                  <div class="form-group">

                      <label for="Email" class="control-label col-xs-3">Message</label>

                      <div class="col-xs-9">
                         <textarea name="message" class="form-control"></textarea>

                      </div>


                  </div>
                   <div class="form-group">

                     

                      <div class="col-xs-offset-3 col-xs-9">
                        <button type="submit" name="btn_submit" class="btn btn-danger">

                          Send

                        </button>

                      </div>


                  </div>



             </form>


          </div>

          <div class="col-md-6">
              <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14133.663612716697!2d85.3142552!3d27.6735377!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x9dbbf0d3224cf118!2sAptech+Computer+Education+lalitpur!5e0!3m2!1sen!2snp!4v1545361479505" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>


          </div>

    </div>

  </div>

</section>