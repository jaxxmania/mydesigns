<?php
 $server="localhost";
  $user="root";
  $pass="";
  $db="mynewsite_db";
  $con=mysqli_connect($server,$user,$pass) or die(mysqli_error());
  mysqli_select_db($con,$db) or die(mysqli_error());


  //Create function for displaying home section 


  function displayHome()
  {
  	 global $con;
  	 $sql="select *from tblHome order by id";
	$qry=mysqli_query($con,$sql);
	$i=0;
	while($row=mysqli_fetch_array($qry))
	{
			$id=$row['id'];
			$title=$row['title'];
			$desc=$row['description'];
			echo "<h1 class='welcome_text page-header' id='Home'>$title</h1>

     	  	  		<p>$desc</p>";
			$i++;
		   
		}
  }
  
?>